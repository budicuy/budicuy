<?php
session_start();
include 'koneksi.php';

$error = "";

// Proses saat form disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nik = $_POST['nik'] ?? '';
    $password = $_POST['password'] ?? '';

    if (!empty($nik) && !empty($password)) {
        // Gunakan prepared statement
        $stmt = mysqli_prepare($conn, "SELECT nik, nama, password, level, id_dept FROM user WHERE nik = ? LIMIT 1");
        mysqli_stmt_bind_param($stmt, "s", $nik);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if ($result && mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);

            // Cek password (hash)
            if (password_verify($password, $row['password'])) {
                // Simpan session
                $_SESSION['nik']     = $row['nik'];
                $_SESSION['nama']    = $row['nama'];
                $_SESSION['level']   = $row['level'];
                $_SESSION['id_dept'] = $row['id_dept'];

                header("Location: dashboard.php");
                exit;
            } 
            // Jika masih pakai plain text password, ganti dengan ini:
            // elseif ($password === $row['password']) { ... }

            else {
                $error = "Password salah!";
            }
        } else {
            $error = "NIK tidak ditemukan!";
        }
        mysqli_stmt_close($stmt);
    } else {
        $error = "Harap isi NIK dan Password!";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login Absensi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-4">
            <div class="card shadow">
                <div class="card-header text-center bg-primary text-white">
                    <h4>Login Absensi</h4>
                </div>
                <div class="card-body">
                    <?php if (!empty($error)): ?>
                        <div class="alert alert-danger"><?= $error; ?></div>
                    <?php endif; ?>
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label for="nik" class="form-label">NIK</label>
                            <input type="text" name="nik" id="nik" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" name="password" id="password" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Login</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
