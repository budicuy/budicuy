<?php
include '../koneksi.php';

// Ambil tab aktif untuk redirect
$tab = $_REQUEST['tab'] ?? 'biasa';

// Fungsi redirect ke daftar absensi
function redirect_to_tab($tab) {
    header("Location: daftar_absensi.php?tab=$tab");
    exit;
}

// Hapus banyak data (multi delete)
if (!empty($_POST['ids']) && is_array($_POST['ids'])) {
    $ids = array_map('intval', $_POST['ids']); // aman dari SQL injection
    $ids_list = implode(',', $ids);

    $sql = "DELETE FROM absensi WHERE id_absen IN ($ids_list)";
    if (mysqli_query($conn, $sql)) {
        redirect_to_tab($tab);
    } else {
        echo "<script>alert('Gagal menghapus data: " . mysqli_error($conn) . "');window.history.back();</script>";
    }
}

// Hapus satu data (single delete via link)
elseif (isset($_GET['id'])) {
    $id = intval($_GET['id']); // aman dari SQL injection

    $sql = "DELETE FROM absensi WHERE id_absen = $id";
    if (mysqli_query($conn, $sql)) {
        redirect_to_tab($tab);
    } else {
        echo "<script>alert('Gagal menghapus data: " . mysqli_error($conn) . "');window.history.back();</script>";
    }
}

// Jika tidak ada data yang dipilih / parameter salah
else {
    redirect_to_tab($tab);
}
?>
