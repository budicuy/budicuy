<?php
include '../koneksi.php';

// tanggal hari ini
$today = date('Y-m-d');

// ambil semua plan overtime hari ini
$plans = mysqli_query($conn, "SELECT * FROM plan_overtime WHERE tanggal='$today'");

if(mysqli_num_rows($plans) > 0){
    while($plan = mysqli_fetch_assoc($plans)){
        // cek apakah absensi untuk NIK dan tanggal ini sudah ada
        $cek = mysqli_query($conn, "SELECT * FROM absensi WHERE nik='".$plan['nik']."' AND tanggal='$today'");
        if(mysqli_num_rows($cek) == 0){
            // ambil jam shift default dari jam_kerja
            $shift = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM jam_kerja WHERE kode_shift='".$plan['kode_shift']."'"));
            
            // gunakan jam lembur dari plan_overtime sebagai jam_masuk/jam_keluar lembur
            $jam_masuk  = $plan['jam_in'] ?: $shift['jam_masuk'];
            $jam_keluar = $plan['jam_out'] ?: $shift['jam_keluar'];
            $reason_id  = $plan['reason_id'] ?: NULL;

            // insert ke absensi
            mysqli_query($conn, "INSERT INTO absensi 
                (nik, tanggal, kode_shift, jam_masuk, jam_keluar, is_lembur, reason_id) 
                VALUES 
                ('".$plan['nik']."', '$today', '".$plan['kode_shift']."', '$jam_masuk', '$jam_keluar', 1, ".($reason_id !== NULL ? $reason_id : "NULL").")"
            );
        }
    }
    echo "<script>alert('Generate absensi dari Plan Overtime berhasil!'); window.location='daftar_absensi.php';</script>";
} else {
    echo "<script>alert('Tidak ada Plan Overtime untuk hari ini.'); window.location='daftar_absensi.php';</script>";
}
?>
