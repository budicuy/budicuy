<?php
include '../koneksi.php';
include '../sidebar.php';
require '../vendor/autoload.php'; // phpoffice/phpspreadsheet

use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Shared\Date;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // ====== Upload Massal Excel ======
    if (isset($_FILES['file_excel']) && $_FILES['file_excel']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['file_excel']['tmp_name'];
        $spreadsheet = IOFactory::load($fileTmpPath);
        $sheet = $spreadsheet->getActiveSheet()->toArray();

        $rowNo = 0;
        $errors = [];
        foreach ($sheet as $row) {
            $rowNo++;
            if ($rowNo == 1) continue; // skip header

            $nik        = trim($row[0]);
            $tanggalRaw = $row[1]; // bisa d-m-Y atau Excel date number
            $kode_shift = trim($row[2]);
            $jam_masuk  = trim($row[3]);
            $jam_keluar = trim($row[4]);
            $is_lembur  = (int)trim($row[5]);
            $reason_id  = !empty($row[6]) ? (int)$row[6] : null;

            // Konversi tanggal
            if (is_numeric($tanggalRaw)) {
                $tanggal = date('Y-m-d', Date::excelToTimestamp($tanggalRaw));
            } else {
                $timestamp = strtotime(str_replace('-', '/', $tanggalRaw));
                if ($timestamp === false) {
                    $errors[] = "Baris $rowNo: Format tanggal '$tanggalRaw' tidak valid.";
                    continue;
                }
                $tanggal = date('Y-m-d', $timestamp);
            }

            // Cek NIK valid
            $cekNik = mysqli_query($conn, "SELECT 1 FROM karyawan WHERE id_nik='$nik'");
            if (mysqli_num_rows($cekNik) === 0) {
                $errors[] = "Baris $rowNo: NIK $nik tidak terdaftar.";
                continue;
            }

            // Ambil jam shift
            $sqlShift  = mysqli_query($conn, "SELECT jam_masuk, jam_keluar FROM jam_kerja WHERE kode_shift='$kode_shift'");
            $shiftData = mysqli_fetch_assoc($sqlShift);
            if (!$shiftData) {
                $errors[] = "Baris $rowNo: Shift $kode_shift tidak valid.";
                continue;
            }
            $jam_masuk_shift  = $shiftData['jam_masuk'];
            $jam_keluar_shift = $shiftData['jam_keluar'];

            // Hitung lembur
            $inEmp  = strtotime($jam_masuk);
            $outEmp = strtotime($jam_keluar);
            $inStd  = strtotime($jam_masuk_shift);
            $outStd = strtotime($jam_keluar_shift);

            if ($outStd <= $inStd) $outStd = strtotime($jam_keluar_shift.' +1 day');
            if ($outEmp < $inEmp) $outEmp = strtotime($jam_keluar.' +1 day');

            $lembur_awal = 0.0;
            $lembur_akhir = 0.0;
            $total_lembur = 0.0;
            if ($is_lembur === 1) {
                if ($inEmp < $inStd) $lembur_awal = ($inStd - $inEmp)/3600;
                if ($outEmp > $outStd) $lembur_akhir = ($outEmp - $outStd)/3600;
                $total_lembur = $lembur_awal + $lembur_akhir;
            }

            // Insert ke database
            $sql = "INSERT INTO absensi
                    (nik, tanggal, is_lembur, kode_shift, jam_masuk, jam_keluar, lembur_awal, lembur_akhir, total_lembur, reason_id)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param(
                $stmt,
                "ssisssdddi",
                $nik,
                $tanggal,
                $is_lembur,
                $kode_shift,
                $jam_masuk,
                $jam_keluar,
                $lembur_awal,
                $lembur_akhir,
                $total_lembur,
                $reason_id
            );
            if (!mysqli_stmt_execute($stmt)) {
                $errors[] = "Baris $rowNo: Gagal insert. ".mysqli_stmt_error($stmt);
            }
        }

        if (!empty($errors)) {
            echo "<div class='alert alert-danger'><strong>Error Upload:</strong><br>".implode('<br>', $errors)."</div>";
        } else {
            echo "<script>alert('Upload massal berhasil!'); window.location='daftar_absensi.php';</script>";
            exit;
        }
    }

    // ====== Input Manual ======
    else {
        $nik        = mysqli_real_escape_string($conn, $_POST['nik'] ?? '');
        $tanggal    = mysqli_real_escape_string($conn, $_POST['tanggal'] ?? '');
        $kode_shift = mysqli_real_escape_string($conn, $_POST['kode_shift'] ?? '');
        $jam_masuk  = mysqli_real_escape_string($conn, $_POST['jam_masuk'] ?? '');
        $jam_keluar = mysqli_real_escape_string($conn, $_POST['jam_keluar'] ?? '');
        $is_lembur  = isset($_POST['is_lembur']) ? (int)$_POST['is_lembur'] : 0;
        $reason_id_post = $_POST['reason_id'] ?? '';

        if ($is_lembur === 1 && $reason_id_post === '') {
            echo "<script>alert('Reason wajib diisi untuk absensi lembur.');history.back();</script>";
            exit;
        }
        $reason_id = ($is_lembur === 1 && $reason_id_post !== '') ? (int)$reason_id_post : null;

        $sqlShift  = mysqli_query($conn, "SELECT jam_masuk, jam_keluar FROM jam_kerja WHERE kode_shift='$kode_shift'");
        $shiftData = mysqli_fetch_assoc($sqlShift);
        if (!$shiftData) {
            echo "<script>alert('Kode shift tidak valid.');history.back();</script>";
            exit;
        }
        $jam_masuk_shift  = $shiftData['jam_masuk'];
        $jam_keluar_shift = $shiftData['jam_keluar'];

        $inEmp   = strtotime($jam_masuk);
        $outEmp  = strtotime($jam_keluar);
        $inStd   = strtotime($jam_masuk_shift);
        $outStd  = strtotime($jam_keluar_shift);

        if ($outStd <= $inStd) $outStd = strtotime($jam_keluar_shift.' +1 day');
        if ($outEmp < $inEmp) $outEmp = strtotime($jam_keluar.' +1 day');

        $lembur_awal = 0.0;
        $lembur_akhir = 0.0;
        $total_lembur = 0.0;
        if ($is_lembur === 1) {
            if ($inEmp < $inStd) $lembur_awal = ($inStd - $inEmp)/3600;
            if ($outEmp > $outStd) $lembur_akhir = ($outEmp - $outStd)/3600;
            $total_lembur = $lembur_awal + $lembur_akhir;
        }

        $sql = "INSERT INTO absensi
                (nik, tanggal, is_lembur, kode_shift, jam_masuk, jam_keluar, lembur_awal, lembur_akhir, total_lembur, reason_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param(
            $stmt,
            "ssisssdddi",
            $nik,
            $tanggal,
            $is_lembur,
            $kode_shift,
            $jam_masuk,
            $jam_keluar,
            $lembur_awal,
            $lembur_akhir,
            $total_lembur,
            $reason_id
        );

        if (mysqli_stmt_execute($stmt)) {
            echo "<script>alert('Absensi berhasil ditambahkan!'); window.location='daftar_absensi.php';</script>";
            exit;
        } else {
            echo "Error insert: ".mysqli_stmt_error($stmt);
            exit;
        }
    }
}

// Data dropdown
$karyawan = mysqli_query($conn, "SELECT id_nik, nama FROM karyawan ORDER BY id_nik");
$shifts   = mysqli_query($conn, "SELECT * FROM jam_kerja ORDER BY kode_shift");
$reasons  = mysqli_query($conn, "SELECT * FROM reason ORDER BY nama_reason");
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Tambah Absensi</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<style>
body { background-color: #f8f9fa; }
.content { margin-left: 240px; padding: 20px; }
.select2-container--default .select2-selection--single { height: 38px; }
</style>
</head>
<body>
<div class="content">
  
  <h2 class="mb-4">Tambah Absensi</h2>

  <!-- Form Upload Excel -->
  <form method="POST" enctype="multipart/form-data" class="mb-4">
    <div class="mb-3">
      <label class="form-label">Upload Excel (NIK, Tanggal d-m-Y, Shift, Jam Masuk, Jam Keluar, is_lembur, Reason_id)</label>
      <input type="file" name="file_excel" class="form-control" accept=".xlsx,.xls">
    </div>
    <button type="submit" class="btn btn-primary">Upload Massal</button>
  </form>

  <hr>

  <!-- Form Manual -->
  <form method="POST">
    <div class="mb-3">
      <label class="form-label">Karyawan</label>
      <select name="nik" id="nik" class="form-select" required>
        <option value="">-- Pilih Karyawan --</option>
        <?php while ($row = mysqli_fetch_assoc($karyawan)) { ?>
          <option value="<?= htmlspecialchars($row['id_nik']) ?>">
            <?= htmlspecialchars($row['id_nik'].' - '.$row['nama']) ?>
          </option>
        <?php } ?>
      </select>
    </div>

    <div class="mb-3">
      <label class="form-label">Tanggal</label>
      <input type="date" name="tanggal" class="form-control" required>
    </div>

    <div class="mb-3">
      <label class="form-label">Jenis Absensi</label><br>
      <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="is_lembur" id="rbBiasa" value="0" checked>
        <label class="form-check-label" for="rbBiasa">Biasa</label>
      </div>
      <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="is_lembur" id="rbLembur" value="1">
        <label class="form-check-label" for="rbLembur">Lembur</label>
      </div>
    </div>

    <div class="mb-3">
      <label class="form-label">Shift</label>
      <select name="kode_shift" id="kode_shift" class="form-select" required>
        <option value="">-- Pilih Shift --</option>
        <?php while ($row = mysqli_fetch_assoc($shifts)) { ?>
          <option value="<?= htmlspecialchars($row['kode_shift']) ?>">
            <?= htmlspecialchars($row['kode_shift'].' ('.$row['jam_masuk'].' - '.$row['jam_keluar'].')') ?>
          </option>
        <?php } ?>
      </select>
    </div>

    <div class="mb-3">
      <label class="form-label">Jam Masuk</label>
      <input type="time" name="jam_masuk" id="jam_masuk" class="form-control" required>
    </div>

    <div class="mb-3">
      <label class="form-label">Jam Keluar</label>
      <input type="time" name="jam_keluar" class="form-control" required>
    </div>

    <div class="mb-3" id="reason_group" style="display:none;">
      <label class="form-label">Reason (Khusus Lembur)</label>
      <select name="reason_id" id="reason_id" class="form-select">
        <option value="">-- Pilih Reason --</option>
        <?php while($r = mysqli_fetch_assoc($reasons)) { ?>
          <option value="<?= (int)$r['reason_id']; ?>"><?= htmlspecialchars($r['nama_reason']); ?></option>
        <?php } ?>
      </select>
    </div>

    <button type="submit" class="btn btn-success">Simpan</button>
    <a href="daftar_absensi.php" class="btn btn-secondary">Kembali</a>
  </form>

</div>

<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
$(document).ready(function(){
    $('#nik').select2({placeholder: "-- Pilih Karyawan --", allowClear:true, width:'100%'});
    $('input[name="is_lembur"]').change(function(){
        if($('#rbLembur').is(':checked')){
            $('#reason_group').show();
        } else {
            $('#reason_group').hide();
            $('#reason_id').val('');
        }
    });
});
</script>
</body>
</html>