<?php
include '../koneksi.php';
include '../sidebar.php';

// Ambil filter tanggal & tab aktif
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : '';
$end_date   = isset($_GET['end_date']) ? $_GET['end_date'] : '';
$active_tab = isset($_GET['tab']) ? $_GET['tab'] : 'biasa'; 

$where = "";
if (!empty($start_date) && !empty($end_date)) {
    $where = "AND a.tanggal BETWEEN '$start_date' AND '$end_date'";
}

// Ambil absensi biasa
$absensi_biasa = mysqli_query($conn, "
    SELECT a.*, k.nama, j.jam_masuk AS shift_in, j.jam_keluar AS shift_out
    FROM absensi a
    JOIN karyawan k ON a.nik = k.id_nik
    JOIN jam_kerja j ON a.kode_shift = j.kode_shift
    WHERE a.is_lembur = 0 $where
    ORDER BY a.tanggal DESC
");

// Ambil absensi lembur
$absensi_lembur_raw = mysqli_query($conn, "
    SELECT a.*, k.nama, j.jam_masuk AS shift_in, j.jam_keluar AS shift_out,
           r.nama_reason
    FROM absensi a
    JOIN karyawan k ON a.nik = k.id_nik
    JOIN jam_kerja j ON a.kode_shift = j.kode_shift
    LEFT JOIN reason r ON a.reason_id = r.reason_id
    WHERE a.is_lembur = 1 $where
    ORDER BY a.tanggal DESC
");

// Proses hitung lembur awal, lembur akhir, total lembur
$absensi_lembur = [];
while($row = mysqli_fetch_assoc($absensi_lembur_raw)){
    $jam_masuk_shift = strtotime($row['shift_in']);
    $jam_keluar_shift = strtotime($row['shift_out']);
    $jam_masuk_emp = strtotime($row['jam_masuk']);
    $jam_keluar_emp = strtotime($row['jam_keluar']);

    if($jam_keluar_shift <= $jam_masuk_shift) $jam_keluar_shift += 24*3600;
    if($jam_keluar_emp <= $jam_masuk_emp) $jam_keluar_emp += 24*3600;

    $lembur_awal = ($jam_masuk_emp < $jam_masuk_shift) ? ($jam_masuk_shift - $jam_masuk_emp)/3600 : 0;
    $lembur_akhir = ($jam_keluar_emp > $jam_keluar_shift) ? ($jam_keluar_emp - $jam_keluar_shift)/3600 : 0;
    $total_lembur = $lembur_awal + $lembur_akhir;

    $row['lembur_awal'] = round($lembur_awal,2);
    $row['lembur_akhir'] = round($lembur_akhir,2);
    $row['total_lembur'] = round($total_lembur,2);

    $absensi_lembur[] = $row;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Daftar Absensi</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
<style>
body { background-color: #f8f9fa; }
.content { margin-left: 240px; padding: 20px; }
</style>
</head>
<body>
<div class="content">
    <h2 class="mb-4">Daftar Absensi</h2>

    <!-- Tombol Tambah & Upload Massal -->
    <a href="tambah_absensi.php" class="btn btn-success mb-3">+ Tambah Absensi</a>
    <a href="generate_absensi.php" class="btn btn-primary mb-3 ms-2" 
      onclick="return confirm('Apakah ingin generate absensi dari Plan Overtime hari ini?')">
      Generate Absensi dari Plan Overtime
    </a>

    <!-- Filter tanggal -->
    <form method="GET" class="row g-3 mb-4">
      <input type="hidden" name="tab" value="<?= htmlspecialchars($active_tab) ?>">
      <div class="col-md-3">
        <label class="form-label">Tanggal Awal</label>
        <input type="date" name="start_date" value="<?= $start_date; ?>" class="form-control">
      </div>
      <div class="col-md-3">
        <label class="form-label">Tanggal Akhir</label>
        <input type="date" name="end_date" value="<?= $end_date; ?>" class="form-control">
      </div>
      <div class="col-md-3 d-flex align-items-end">
        <button type="submit" class="btn btn-primary me-2">Filter</button>
        <a href="daftar_absensi.php?tab=<?= $active_tab ?>" class="btn btn-secondary">Reset</a>
      </div>
    </form>

    <!-- Tabs -->
    <ul class="nav nav-tabs" id="myTab" role="tablist">
      <li class="nav-item" role="presentation">
        <button class="nav-link <?= $active_tab=='biasa'?'active':'' ?>" id="biasa-tab" data-bs-toggle="tab" data-bs-target="#biasa" type="button">Absensi Biasa</button>
      </li>
      <li class="nav-item" role="presentation">
        <button class="nav-link <?= $active_tab=='lembur'?'active':'' ?>" id="lembur-tab" data-bs-toggle="tab" data-bs-target="#lembur" type="button">Absensi Lembur</button>
      </li>
    </ul>

    <!-- Content Tabs -->
    <div class="tab-content mt-3">
      <!-- Absensi Biasa -->
      <div class="tab-pane fade <?= $active_tab=='biasa'?'show active':'' ?>" id="biasa">
        <form method="POST" action="hapus_absensi.php" onsubmit="return confirm('Yakin hapus data terpilih?');">
          <input type="hidden" name="tab" value="biasa">
          <div class="mb-2">
            <button type="submit" class="btn btn-danger btn-sm">Hapus Terpilih</button>
          </div>
          <div class="table-responsive">
            <table id="tableBiasa" class="table table-bordered table-striped align-middle">
              <thead class="table-dark text-center">
                <tr>
                  <th><input type="checkbox" id="checkAllBiasa"></th>
                  <th style="width:50px;">No</th>
                  <th>Tanggal</th>
                  <th>NIK</th>
                  <th>Nama</th>
                  <th>Shift</th>
                  <th>Jam Masuk</th>
                  <th>Jam Keluar</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php $no=1; while($row = mysqli_fetch_assoc($absensi_biasa)) { ?>
                <tr>
                  <td class="text-center"><input type="checkbox" name="ids[]" value="<?= $row['id_absen'] ?>"></td>
                  <td class="text-center"><?= $no++; ?></td>
                  <td><?= $row['tanggal']; ?></td>
                  <td><?= $row['nik']; ?></td>
                  <td><?= $row['nama']; ?></td>
                  <td><?= $row['kode_shift'].' ('.$row['shift_in'].'-'.$row['shift_out'].')'; ?></td>
                  <td><?= $row['jam_masuk']; ?></td>
                  <td><?= $row['jam_keluar']; ?></td>
                  <td class="text-center">
                    <div class="btn-group" role="group">
                      <a href="edit_absensi.php?id=<?= $row['id_absen']; ?>" class="btn btn-warning btn-sm">Edit</a>
                      <a href="hapus_absensi.php?id=<?= $row['id_absen']; ?>&tab=biasa" class="btn btn-danger btn-sm" onclick="return confirm('Yakin hapus data ini?')">Hapus</a>
                    </div>
                  </td>
                </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>
        </form>
      </div>

      <!-- Absensi Lembur -->
      <div class="tab-pane fade <?= $active_tab=='lembur'?'show active':'' ?>" id="lembur">
        <form method="POST" action="hapus_absensi.php" onsubmit="return confirm('Yakin hapus data terpilih?');">
          <input type="hidden" name="tab" value="lembur">
          <div class="mb-2">
            <button type="submit" class="btn btn-danger btn-sm">Hapus Terpilih</button>
          </div>
          <div class="table-responsive">
            <table id="tableLembur" class="table table-bordered table-striped align-middle">
              <thead class="table-dark text-center">
                <tr>
                  <th><input type="checkbox" id="checkAllLembur"></th>
                  <th style="width:50px;">No</th>
                  <th>Tanggal</th>
                  <th>NIK</th>
                  <th>Nama</th>
                  <th>Shift</th>
                  <th>Jam Masuk</th>
                  <th>Jam Keluar</th>
                  <th>Lembur Awal</th>
                  <th>Lembur Akhir</th>
                  <th>Total Lembur (Jam)</th>
                  <th>Reason</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php $no=1; foreach($absensi_lembur as $row) { ?>
                <tr>
                  <td class="text-center"><input type="checkbox" name="ids[]" value="<?= $row['id_absen'] ?>"></td>
                  <td class="text-center"><?= $no++; ?></td>
                  <td><?= $row['tanggal']; ?></td>
                  <td><?= $row['nik']; ?></td>
                  <td><?= $row['nama']; ?></td>
                  <td><?= $row['kode_shift'].' ('.$row['shift_in'].'-'.$row['shift_out'].')'; ?></td>
                  <td><?= $row['jam_masuk']; ?></td>
                  <td><?= $row['jam_keluar']; ?></td>
                  <td class="text-center"><?= $row['lembur_awal']; ?></td>
                  <td class="text-center"><?= $row['lembur_akhir']; ?></td>
                  <td class="text-center"><strong><?= $row['total_lembur']; ?></strong></td>
                  <td><?= $row['nama_reason']; ?></td>
                  <td class="text-center">
                    <div class="btn-group" role="group">
                      <a href="edit_absensi.php?id=<?= $row['id_absen']; ?>" class="btn btn-warning btn-sm">Edit</a>
                      <a href="hapus_absensi.php?id=<?= $row['id_absen']; ?>&tab=lembur" class="btn btn-danger btn-sm" onclick="return confirm('Yakin hapus data ini?')">Hapus</a>
                    </div>
                  </td>
                </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>
        </form>
      </div>

    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
$(document).ready(function(){
    $('#tableBiasa').DataTable({
        columnDefs: [{ orderable: false, targets: [0,8] }],
        order: [[1,'desc']],
        drawCallback: function(settings){ this.api().column(1,{page:'current'}).nodes().each((cell,i)=>cell.innerHTML=i+1); }
    });
    $('#tableLembur').DataTable({
        columnDefs: [{ orderable: false, targets: [0,12] }],
        order: [[1,'desc']],
        drawCallback: function(settings){ this.api().column(1,{page:'current'}).nodes().each((cell,i)=>cell.innerHTML=i+1); }
    });

    // Aktifkan tab sesuai parameter
    var activeTab = "<?= $active_tab ?>";
    if(activeTab){
        var triggerEl = document.querySelector('#myTab button[data-bs-target="#'+activeTab+'"]');
        if(triggerEl){ var tab = new bootstrap.Tab(triggerEl); tab.show(); }
    }

    // Checkbox select all
    $('#checkAllBiasa').click(function(){ $('#tableBiasa input[name="ids[]"]').prop('checked', this.checked); });
    $('#checkAllLembur').click(function(){ $('#tableLembur input[name="ids[]"]').prop('checked', this.checked); });
});
</script>
</body>
</html>
