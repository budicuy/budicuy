<?php
include '../koneksi.php';
include '../sidebar.php';



// Ambil ID dari parameter
$id = $_GET['id'] ?? null;
if (!$id) {
    die("ID Absensi tidak ditemukan!");
}

// Ambil data absensi berdasarkan ID
$query = "SELECT * FROM absensi WHERE id_absen = '$id'";
$result = mysqli_query($conn, $query);
$data = mysqli_fetch_assoc($result);

if (!$data) {
    die("Data absensi tidak ditemukan!");
}

// Ambil daftar reason
$reasons = mysqli_query($conn, "SELECT * FROM reason");

// Ambil data karyawan
$karyawanQuery = mysqli_query($conn, "SELECT id_nik, nama FROM karyawan");

// Ambil data shift
$shiftQuery = mysqli_query($conn, "SELECT * FROM jam_kerja");

// Jika form disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nik        = $_POST['nik'];
    $tanggal    = $_POST['tanggal'];
    $kode_shift = $_POST['kode_shift'];
    $jam_masuk  = $_POST['jam_masuk'];
    $jam_keluar = $_POST['jam_keluar'];
    $reason_id  = $_POST['reason_id'];
    $is_lembur  = isset($_POST['is_lembur']) ? 1 : 0; // checkbox

    // Ambil data shift (jam kerja normal)
    $shiftData = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM jam_kerja WHERE kode_shift='$kode_shift'"));
    $shiftMasuk = $shiftData['jam_masuk'];
    $shiftKeluar = $shiftData['jam_keluar'];

    // Konversi ke detik
    $jamMasuk = strtotime($jam_masuk);
    $jamKeluar = strtotime($jam_keluar);
    $shiftMasukDetik = strtotime($shiftMasuk);
    $shiftKeluarDetik = strtotime($shiftKeluar);

    // Jika jam keluar lebih kecil dari jam masuk, berarti lewat tengah malam → tambah 1 hari
    if ($jamKeluar < $jamMasuk) {
        $jamKeluar = strtotime($jam_keluar . ' +1 day');
    }

    // Hitung lembur awal (jika masuk lebih awal dari jam shift)
    $lembur_awal = 0;
    if ($jamMasuk < $shiftMasukDetik) {
        $lembur_awal = ($shiftMasukDetik - $jamMasuk) / 3600;
    }

    // Hitung lembur akhir (jika keluar lebih lama dari jam shift)
    $lembur_akhir = 0;
    if ($jamKeluar > $shiftKeluarDetik) {
        $lembur_akhir = ($jamKeluar - $shiftKeluarDetik) / 3600;
    }

    // Total lembur
    $total_lembur = $lembur_awal + $lembur_akhir;

    // Update data
    $update = "
        UPDATE absensi SET 
            nik='$nik', 
            tanggal='$tanggal', 
            kode_shift='$kode_shift', 
            jam_masuk='$jam_masuk', 
            jam_keluar='$jam_keluar', 
            lembur_awal='$lembur_awal',
            lembur_akhir='$lembur_akhir',
            total_lembur='$total_lembur',
            reason_id='$reason_id',
            is_lembur='$is_lembur'
        WHERE id_absen='$id'
    ";

    if (mysqli_query($conn, $update)) {
        echo "<script>alert('Data absensi berhasil diperbarui!'); window.location='daftar_absensi.php';</script>";
    } else {
        echo "<script>alert('Gagal memperbarui data!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Edit Absensi</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <style>
    .content {
        margin-left: 240px; /* menyesuaikan sidebar */
        padding: 20px;
    }
    .card {
        background: #fff;
        border-radius: 8px;
        padding: 20px;
        box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }
  </style>
</head>
<body>
<div class="content">
  <div class="container-fluid">
    <h2 class="mb-4">Edit Absensi</h2>
    <div class="card">
      <form method="POST">
        <div class="mb-3">
          <label for="nik" class="form-label">Karyawan</label>
          <select name="nik" id="nik" class="form-select" required>
            <option value="">-- Pilih Karyawan --</option>
            <?php while ($k = mysqli_fetch_assoc($karyawanQuery)) { ?>
              <option value="<?= $k['id_nik'] ?>" <?= $k['id_nik'] == $data['nik'] ? 'selected' : '' ?>>
                <?= $k['id_nik'] ?> - <?= $k['nama'] ?>
              </option>
            <?php } ?>
          </select>
        </div>

        <div class="mb-3">
          <label for="tanggal" class="form-label">Tanggal</label>
          <input type="date" name="tanggal" id="tanggal" class="form-control" value="<?= $data['tanggal'] ?>" required>
        </div>

        <div class="mb-3">
          <label for="kode_shift" class="form-label">Shift</label>
          <select name="kode_shift" id="kode_shift" class="form-select" required>
            <option value="">-- Pilih Shift --</option>
            <?php
            mysqli_data_seek($shiftQuery, 0);
            while ($s = mysqli_fetch_assoc($shiftQuery)) { ?>
              <option value="<?= $s['kode_shift'] ?>" data-jammasuk="<?= $s['jam_masuk'] ?>" <?= $s['kode_shift'] == $data['kode_shift'] ? 'selected' : '' ?>>
                <?= $s['kode_shift'] ?> (<?= $s['jam_masuk'] ?> - <?= $s['jam_keluar'] ?>)
              </option>
            <?php } ?>
          </select>
        </div>

        <div class="mb-3">
          <label for="jam_masuk" class="form-label">Jam Masuk</label>
          <input type="time" name="jam_masuk" id="jam_masuk" class="form-control" value="<?= $data['jam_masuk'] ?>" required>
        </div>

        <div class="mb-3">
          <label for="jam_keluar" class="form-label">Jam Keluar</label>
          <input type="time" name="jam_keluar" id="jam_keluar" class="form-control" value="<?= $data['jam_keluar'] ?>" required>
        </div>

        <div class="mb-3">
          <label class="form-label">Reason</label>
          <select name="reason_id" class="form-select" required>
            <option value="">-- Pilih Reason --</option>
            <?php mysqli_data_seek($reasons, 0); while($r = mysqli_fetch_assoc($reasons)) { ?>
              <option value="<?= $r['reason_id']; ?>" <?= $r['reason_id'] == $data['reason_id'] ? 'selected' : '' ?>>
                <?= $r['nama_reason']; ?>
              </option>
            <?php } ?>
          </select>
        </div>

        <div class="form-check mb-3">
          <input type="checkbox" class="form-check-input" name="is_lembur" id="is_lembur" value="1" <?= $data['is_lembur'] ? 'checked' : '' ?>>
          <label for="is_lembur" class="form-check-label">Tandai sebagai Lembur</label>
        </div>

        <button type="submit" class="btn btn-warning">Update</button>
        <a href="daftar_absensi.php" class="btn btn-secondary">Kembali</a>
      </form>
    </div>
  </div>
</div>

<script>
$(document).ready(function() {
  $("#kode_shift").on("change", function() {
    var jamMasuk = $(this).find(":selected").data("jammasuk");
    if (jamMasuk) {
      $("#jam_masuk").val(jamMasuk);
    }
  });
});
</script>
</body>
</html>
