<?php
session_start();
include '../koneksi.php';
include '../sidebar.php';

// Load PhpSpreadsheet via Composer
require '../vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\IOFactory;

// Fungsi untuk convert dd-mm-yyyy ke YYYY-MM-DD
function formatTanggalDB($tgl){
    $parts = explode('-', $tgl);
    if(count($parts)==3){
        return $parts[2].'-'.$parts[1].'-'.$parts[0];
    }
    return date('Y-m-d');
}

// Proses Upload Excel
$success_count = 0;
$error_messages = [];

if(isset($_POST['upload_excel'])){
    if(isset($_FILES['file_excel']['tmp_name'])){
        $file = $_FILES['file_excel']['tmp_name'];
        $spreadsheet = IOFactory::load($file);
        $sheet = $spreadsheet->getActiveSheet();
        $rows = $sheet->toArray();

        foreach($rows as $i => $row){
            if($i==0) continue; // skip header
            $nik = mysqli_real_escape_string($conn, $row[0] ?? '');
            $tgl_input = $row[1] ?? '';
            $tanggal = formatTanggalDB($tgl_input);
            $kode_shift = mysqli_real_escape_string($conn, $row[2] ?? '');
            $jam_masuk  = $row[3] ?? '';
            $jam_keluar = $row[4] ?? '';
            $is_lembur  = isset($row[5]) && $row[5]=='1' ? 1 : 0;
            $reason_id  = $is_lembur ? (int)($row[6] ?? null) : null;

            // Ambil jam shift
            $shiftQ = mysqli_query($conn, "SELECT jam_masuk, jam_keluar FROM jam_kerja WHERE kode_shift='$kode_shift'");
            $shift = mysqli_fetch_assoc($shiftQ);
            if(!$shift){
                $error_messages[] = "Baris ".($i+1).": Kode shift '$kode_shift' tidak valid.";
                continue;
            }
            $shift_in  = strtotime($shift['jam_masuk']);
            $shift_out = strtotime($shift['jam_keluar']);
            $emp_in    = strtotime($jam_masuk);
            $emp_out   = strtotime($jam_keluar);

            // koreksi untuk shift keluar malam
            if($shift_out <= $shift_in) $shift_out += 24*3600;
            if($emp_out < $emp_in) $emp_out += 24*3600;

            // Hitung lembur
            $lembur_awal = 0;
            $lembur_akhir = 0;
            if($is_lembur){
                if($emp_in < $shift_in) $lembur_awal = ($shift_in - $emp_in)/3600;
                if($emp_out > $shift_out) $lembur_akhir = ($emp_out - $shift_out)/3600;
            }
            $total_lembur = $lembur_awal + $lembur_akhir;

            $stmt = mysqli_prepare($conn, "INSERT INTO absensi
                (nik,tanggal,is_lembur,kode_shift,jam_masuk,jam_keluar,lembur_awal,lembur_akhir,total_lembur,reason_id)
                VALUES(?,?,?,?,?,?,?,?,?,?)");
            mysqli_stmt_bind_param($stmt,"ssisssdddi",$nik,$tanggal,$is_lembur,$kode_shift,$jam_masuk,$jam_keluar,$lembur_awal,$lembur_akhir,$total_lembur,$reason_id);
            if(mysqli_stmt_execute($stmt)) $success_count++;
            else $error_messages[] = "Baris ".($i+1).": ".mysqli_stmt_error($stmt);
        }
    }
}

// Ambil data karyawan & shift & reason
$karyawan = mysqli_query($conn, "SELECT id_nik,nama FROM karyawan ORDER BY id_nik");
$shifts   = mysqli_query($conn, "SELECT * FROM jam_kerja ORDER BY kode_shift");
$reasons  = mysqli_query($conn, "SELECT * FROM reason ORDER BY nama_reason");
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Upload & Input Absensi</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.1.0/css/select2.min.css" rel="stylesheet" />
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.1.0/js/select2.min.js"></script>
<style>
body { background-color: #f8f9fa; }
.content { margin-left: 240px; padding: 20px; }
.card { border-radius:15px; box-shadow:0 4px 6px rgba(0,0,0,0.1); }
</style>
</head>
<body>
<div class="content">
  <div class="card p-4">
    <h2 class="mb-4">Upload & Input Absensi</h2>

    <!-- Hasil Upload -->
    <?php if($success_count>0): ?>
        <div class="alert alert-success"><?= $success_count ?> data berhasil diupload</div>
    <?php endif; ?>
    <?php if(count($error_messages)>0): ?>
        <div class="alert alert-danger">
            <?php foreach($error_messages as $err) echo $err."<br>"; ?>
        </div>
    <?php endif; ?>

    <!-- Form Upload Excel -->
    <form method="POST" enctype="multipart/form-data" class="mb-4">
        <div class="mb-3">
            <label>Upload File Excel (.xlsx)</label>
            <input type="file" name="file_excel" class="form-control" accept=".xlsx" required>
        </div>
        <button type="submit" name="upload_excel" class="btn btn-primary">Upload Excel</button>
    </form>

    <hr>

    <!-- Form Input Manual -->
    <h4>Input Manual</h4>
    <form method="POST" action="proses_manual_absensi.php">
        <div class="mb-3">
            <label>Karyawan</label>
            <select name="nik" class="form-control select2" required>
                <option value="">-- Pilih Karyawan --</option>
                <?php while($row=mysqli_fetch_assoc($karyawan)): ?>
                    <option value="<?= $row['id_nik'] ?>"><?= $row['id_nik'].' - '.$row['nama'] ?></option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="mb-3">
            <label>Tanggal</label>
            <input type="text" name="tanggal" id="tanggal" class="form-control" placeholder="dd-mm-yyyy" required>
        </div>
        <div class="mb-3">
            <label>Shift</label>
            <select name="kode_shift" id="kode_shift" class="form-control" required>
                <option value="">-- Pilih Shift --</option>
                <?php while($row=mysqli_fetch_assoc($shifts)): ?>
                    <option value="<?= $row['kode_shift'] ?>"><?= $row['kode_shift'].' ('.$row['jam_masuk'].'-'.$row['jam_keluar'].')' ?></option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="mb-3">
            <label>Jam Masuk</label>
            <input type="time" name="jam_masuk" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Jam Keluar</label>
            <input type="time" name="jam_keluar" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Jenis Absensi</label><br>
            <input type="radio" name="is_lembur" value="0" checked> Biasa
            <input type="radio" name="is_lembur" value="1"> Lembur
        </div>
        <div class="mb-3" id="reason_group" style="display:none;">
            <label>Reason (Lembur)</label>
            <select name="reason_id" class="form-control">
                <option value="">-- Pilih Reason --</option>
                <?php while($r=mysqli_fetch_assoc($reasons)): ?>
                    <option value="<?= $r['reason_id'] ?>"><?= $r['nama_reason'] ?></option>
                <?php endwhile; ?>
            </select>
        </div>
        <button type="submit" class="btn btn-success">Simpan Manual</button>
    </form>
  </div>
</div>

<script>
$(document).ready(function(){
    $('.select2').select2();

    // Toggle reason
    $('input[name="is_lembur"]').change(function(){
        if($(this).val()=='1') $('#reason_group').show();
        else { $('#reason_group').hide(); $('#reason_group select').val(''); }
    });

    // Date format placeholder
    $('#tanggal').on('focus',function(){ $(this).attr('placeholder','dd-mm-yyyy'); });
});
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
