<?php
session_start();

// Cek kalau belum login
if (!isset($_SESSION['nik']) || !isset($_SESSION['level'])) {
    header("Location: ../login.php");
    exit();
}

// Simpan level user dari session
$level = $_SESSION['level'];

/**
 * Fungsi cek akses berdasarkan level
 * Contoh: cekAkses(['Super Admin','Admin']);
 */
function cekAkses($allowedLevels = []) {
    global $level;

    if (!in_array($level, $allowedLevels)) {
        echo "<div style='color:red; font-weight:bold; text-align:center; margin-top:20px;'>
                ❌ Akses ditolak. Anda tidak punya izin!
              </div>";
        exit();
    }
}
