<?php
include '../koneksi.php';
include '../sidebar.php';

// Ambil filter tanggal (jika ada)
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : '';
$end_date   = isset($_GET['end_date']) ? $_GET['end_date'] : '';

// Validasi tanggal: jika kosong, pakai default bulan ini
if (empty($start_date) || empty($end_date)) {
    $start_date = date('Y-m-01'); // tanggal pertama bulan ini
    $end_date   = date('Y-m-d');  // tanggal hari ini
}

// Query laporan absensi
$query = "
SELECT k.id_nik, k.nama, d.nama_departemen AS departemen,
       COUNT(a.id_absen) AS jumlah_hadir,
       SUM(a.total_lembur) AS total_lembur,
       SUM(ROUND(a.total_lembur * g.gaji_pokok / 173, 0)) AS total_biaya
FROM absensi a
JOIN (
    SELECT gp1.*
    FROM gaji_pokok gp1
    JOIN (
        SELECT id_nik, MAX(CONCAT(tahun, LPAD(bulan,2,'0'))) AS periode
        FROM gaji_pokok
        GROUP BY id_nik
    ) gp2 ON gp1.id_nik = gp2.id_nik
       AND CONCAT(gp1.tahun, LPAD(gp1.bulan,2,'0')) = gp2.periode
) g ON g.id_nik = a.nik
JOIN karyawan k ON a.nik = k.id_nik
LEFT JOIN departemen d ON k.id_dept = d.id_dept
WHERE a.tanggal BETWEEN '$start_date' AND '$end_date'
GROUP BY k.id_nik, k.nama, d.nama_departemen
ORDER BY k.nama ASC
";

$result = mysqli_query($conn, $query);

// Fungsi format jam
function formatJam($decimal) {
    $jam = floor($decimal);
    $menit = round(($decimal - $jam) * 60);
    $hasil = "";
    if ($jam > 0) $hasil .= $jam." jam";
    if ($menit > 0) $hasil .= " ".$menit." menit";
    if ($hasil == "") $hasil = "0 menit";
    return trim($hasil);
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Laporan Absensi</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
  <style>
    .content { margin-left: 240px; padding: 20px; }
    .table { font-size: 14px; vertical-align: middle; }
    .table th, .table td { white-space: nowrap; }
  </style>
</head>
<body>
<div class="content">

<div class="mb-3">
   <a href="../proses/export_laporan.php?start_date=<?= $start_date; ?>&end_date=<?= $end_date; ?>" class="btn btn-success">Export All to Excel</a>
   <a href="export_pdf.php?start_date=<?= $start_date ?>&end_date=<?= $end_date ?>" class="btn btn-danger">Export PDF</a>
</div>

<h2 class="mb-4">LAPORAN ABSENSI</h2>

<!-- Filter tanggal -->
<form method="GET" class="row g-3 mb-3">
    <div class="col-auto">
        <input type="date" name="start_date" value="<?= $start_date ?>" class="form-control" required>
    </div>
    <div class="col-auto">
        <input type="date" name="end_date" value="<?= $end_date ?>" class="form-control" required>
    </div>
    <div class="col-auto">
        <button type="submit" class="btn btn-primary">Filter</button>
        <a href="laporan_absensi.php" class="btn btn-secondary">Reset</a>
    </div>
</form>

<div class="table-responsive">
    <table id="laporanTable" class="table table-striped table-bordered">
      <thead class="table-dark">
        <tr>
          <th>No</th>
          <th>NIK</th>
          <th>Nama</th>
          <th>Departemen</th>
          <th>Jumlah Hadir</th>
          <th>Total Lembur</th>
          <th>Total Biaya Lembur</th>
        </tr>
      </thead>
      <tbody>
        <?php
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                $biaya = $row['total_biaya'] ?? 0;
                echo "<tr>";
                echo "<td></td>"; // nomor otomatis oleh DataTables
                echo "<td>".$row['id_nik']."</td>";
                echo "<td>".$row['nama']."</td>";
                echo "<td>".$row['departemen']."</td>";
                echo "<td>".$row['jumlah_hadir']."</td>";
                echo "<td>".formatJam($row['total_lembur'])."</td>";
                echo "<td>Rp ".number_format((float)$biaya,0,",",".")."</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='7' class='text-center'>Tidak ada data untuk periode ini</td></tr>";
        }
        ?>
      </tbody>
    </table>
</div>

</div>

<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
<script>
$(document).ready(function() {
  var t = $('#laporanTable').DataTable({
    "columnDefs": [{
      "searchable": false,
      "orderable": false,
      "targets": 0
    }],
    "order": [[1, 'asc']],
    "pageLength": 50,
    "lengthChange": false
  });

  t.on('order.dt search.dt', function () {
    let i = 1;
    t.cells(null, 0, { search: 'applied', order: 'applied' }).every(function () {
      this.data(i++);
    });
  }).draw();
});
</script>

</body>
</html>
