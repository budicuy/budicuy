<?php
// export_excel.php
include '../koneksi.php';
require '../vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

// Ambil filter tanggal
$start_date = $_GET['start_date'] ?? '';
$end_date   = $_GET['end_date'] ?? '';

$where = "1";
if (!empty($start_date) && !empty($end_date)) {
    $where .= " AND a.tanggal BETWEEN '$start_date' AND '$end_date'";
}

// Query data
$query = "
SELECT 
    k.id_nik AS nik,
    k.nama,
    d.nama_departemen AS departemen,
    COUNT(a.id_absen) AS jumlah_hadir,
    SUM(a.total_lembur) AS total_lembur,
    COALESCE(SUM((a.total_lembur * (g.gaji_pokok / 173))),0) AS total_biaya
FROM absensi a
JOIN karyawan k ON a.nik = k.id_nik
LEFT JOIN departemen d ON k.id_dept = d.id_dept
LEFT JOIN (
    SELECT gp1.*
    FROM gaji_pokok gp1
    JOIN (
        SELECT id_nik, MAX(CONCAT(tahun, LPAD(bulan,2,'0'))) AS periode
        FROM gaji_pokok
        GROUP BY id_nik
    ) gp2 ON gp1.id_nik = gp2.id_nik
    AND CONCAT(gp1.tahun, LPAD(gp1.bulan,2,'0')) = gp2.periode
) g ON g.id_nik = k.id_nik
WHERE $where
GROUP BY k.id_nik, k.nama, d.nama_departemen
ORDER BY d.nama_departemen, k.nama
";

$result = mysqli_query($conn, $query);

// Buat Excel
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

// Header
$sheet->setCellValue('A1','No')
      ->setCellValue('B1','NIK')
      ->setCellValue('C1','Nama')
      ->setCellValue('D1','Departemen')
      ->setCellValue('E1','Jumlah Hadir')
      ->setCellValue('F1','Total Lembur')
      ->setCellValue('G1','Total Biaya Lembur');

// Data
$rowNum = 2;
$no = 1;
while($row = mysqli_fetch_assoc($result)){
    $sheet->setCellValue('A'.$rowNum,$no++)
          ->setCellValue('B'.$rowNum,$row['nik'])
          ->setCellValue('C'.$rowNum,$row['nama'])
          ->setCellValue('D'.$rowNum,$row['departemen'])
          ->setCellValue('E'.$rowNum,$row['jumlah_hadir'])
          ->setCellValue('F'.$rowNum,$row['total_lembur'])
          ->setCellValue('G'.$rowNum,$row['total_biaya']);
    $rowNum++;
}

// Output
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="laporan_absensi.xlsx"');
header('Cache-Control: max-age=0');

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
