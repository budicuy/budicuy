<?php
include '../koneksi.php';
require_once('../vendor/autoload.php'); // TCPDF sudah include

// Ambil filter tanggal
$start_date = $_GET['start_date'] ?? '';
$end_date   = $_GET['end_date'] ?? '';

// Filter
$where = "1";
if (!empty($start_date) && !empty($end_date)) {
    $where .= " AND a.tanggal BETWEEN '$start_date' AND '$end_date'";
}

// Query data
$query = "
SELECT 
    k.id_nik AS nik,
    k.nama,
    d.nama_departemen AS departemen,
    COUNT(a.id_absen) AS jumlah_hadir,
    SUM(a.total_lembur) AS total_lembur,
    COALESCE(SUM((a.total_lembur * (g.gaji_pokok / 173))),0) AS total_biaya
FROM absensi a
JOIN karyawan k ON a.nik = k.id_nik
LEFT JOIN departemen d ON k.id_dept = d.id_dept
LEFT JOIN (
    SELECT gp1.*
    FROM gaji_pokok gp1
    JOIN (
        SELECT id_nik, MAX(CONCAT(tahun, LPAD(bulan,2,'0'))) AS periode
        FROM gaji_pokok
        GROUP BY id_nik
    ) gp2 ON gp1.id_nik = gp2.id_nik
    AND CONCAT(gp1.tahun, LPAD(gp1.bulan,2,'0')) = gp2.periode
) g ON g.id_nik = k.id_nik
WHERE $where
GROUP BY k.id_nik, k.nama, d.nama_departemen
ORDER BY d.nama_departemen, k.nama
";

$result = mysqli_query($conn, $query);

// PDF
$pdf = new TCPDF('L','mm','A4',true,'UTF-8',false);
$pdf->SetTitle('Laporan Absensi');
$pdf->SetMargins(10,10,10);
$pdf->AddPage();
$pdf->SetFont('helvetica','',10);

$html = '<h3>Laporan Absensi</h3>';
$html .= '<table border="1" cellpadding="4">
<thead>
<tr style="background-color:#cccccc;">
<th>No</th><th>NIK</th><th>Nama</th><th>Departemen</th><th>Jumlah Hadir</th><th>Total Lembur</th><th>Total Biaya Lembur</th>
</tr>
</thead>
<tbody>';

$no = 1;
while($row = mysqli_fetch_assoc($result)){
    $html .= '<tr>
    <td>'.$no++.'</td>
    <td>'.$row['nik'].'</td>
    <td>'.$row['nama'].'</td>
    <td>'.$row['departemen'].'</td>
    <td>'.$row['jumlah_hadir'].'</td>
    <td>'.$row['total_lembur'].'</td>
    <td>Rp '.number_format($row['total_biaya'],0,",",".").'</td>
    </tr>';
}

$html .= '</tbody></table>';

$pdf->writeHTML($html,true,false,true,false,'');
$pdf->Output('laporan_absensi.pdf','I'); // output langsung ke browser
exit;
