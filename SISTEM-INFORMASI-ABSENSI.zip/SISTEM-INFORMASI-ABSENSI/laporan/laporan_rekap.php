<?php
include '../koneksi.php';
include '../sidebar.php';

$bulan = isset($_GET['bulan']) ? $_GET['bulan'] : date('n');
$tahun = isset($_GET['tahun']) ? $_GET['tahun'] : date('Y');

/**
 * Hitung total hari kerja dalam 1 bulan (Senin–Jumat)
 */
function getHariKerja($bulan, $tahun) {
    $hariKerja = 0;
    $totalHari = cal_days_in_month(CAL_GREGORIAN, $bulan, $tahun);
    for ($i=1; $i <= $totalHari; $i++) {
        $day = date('N', strtotime("$tahun-$bulan-$i")); // 1=Senin ... 7=Minggu
        if ($day < 6) { // Senin–Jumat
            $hariKerja++;
        }
    }
    return $hariKerja;
}

$hariKerja = getHariKerja($bulan, $tahun);

// Query rekap
$sql = "SELECT orp.id_rekap, orp.id_nik, k.nama, d.nama_departemen, v.nama_vendor,
               orp.bulan, orp.tahun, orp.total_jam, orp.total_biaya, 
               gp.gaji_pokok, orp.ranking
        FROM overtime_rekap orp
        JOIN karyawan k ON orp.id_nik = k.id_nik
        JOIN vendor v ON k.id_vendor = v.id_vendor
        JOIN departemen d ON k.id_dept = d.id_dept
        LEFT JOIN gaji_pokok gp ON gp.id_nik = k.id_nik
        WHERE orp.bulan = ? AND orp.tahun = ?
        ORDER BY orp.ranking ASC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $bulan, $tahun);
$stmt->execute();
$result = $stmt->get_result();
?>

<style>
.main-content {
    margin-left: 220px; /* agar nempel sidebar */
    padding: 20px;
}
</style>

<div class="main-content">
    <h3>Laporan Overtime Rekap (<?= date("F", mktime(0,0,0,$bulan,1)); ?> <?= $tahun; ?>)</h3>

    <!-- Filter -->
    <form method="get" class="row mb-3">
        <div class="col-md-3">
            <select name="bulan" class="form-control">
                <?php 
                for ($i = 1; $i <= 12; $i++) {
                    $selected = ($i == $bulan) ? "selected" : "";
                    echo "<option value='$i' $selected>".date("F", mktime(0,0,0,$i,1))."</option>";
                }
                ?>
            </select>
        </div>
        <div class="col-md-2">
            <select name="tahun" class="form-control">
                <?php 
                $tahunSekarang = date('Y');
                for ($i = $tahunSekarang-5; $i <= $tahunSekarang+1; $i++) {
                    $selected = ($i == $tahun) ? "selected" : "";
                    echo "<option value='$i' $selected>$i</option>";
                }
                ?>
            </select>
        </div>
        <div class="col-md-2">
            <button type="submit" class="btn btn-primary">Filter</button>
            <a href="laporan_rekap.php" class="btn btn-secondary">Reset</a>
        </div>
        <div class="col-md-3">
            <a href="../proses/generate_overtime.php?bulan=<?= $bulan; ?>&tahun=<?= $tahun; ?>" 
               class="btn btn-success">
               🔄 Generate Overtime
            </a>
        </div>
    </form>

    <a href="../proses/export_laporan.php?bulan=<?= $bulan; ?>&tahun=<?= $tahun; ?>" 
   class="btn btn-success">Export All to Excel</a>


    <?php if (isset($_GET['msg']) && $_GET['msg'] == 'generated'): ?>
        <div class="alert alert-success">✅ Data overtime berhasil digenerate!</div>
    <?php endif; ?>

    <!-- Tabel -->
    <table id="datatable" class="table table-bordered table-striped text-start">
        <thead class="table-dark">
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Departemen</th>
                <th>Vendor</th>
                <th>Total Jam</th>
                <th>Rp. Ovt</th>
                <th>GP</th>
                <th>%</th>
                <th>Rank</th>
                <th>Avg Ovt by Day</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): 
                $persen = ($row['gaji_pokok'] > 0) ? ($row['total_biaya'] / $row['gaji_pokok']) * 100 : 0;
                $avgOvt = ($hariKerja > 0) ? $row['total_jam'] / $hariKerja : 0;
            ?>
            <tr>
                <td></td> <!-- nomor otomatis -->
                <td><?= htmlspecialchars($row['nama']); ?></td>
                <td><?= htmlspecialchars($row['nama_departemen']); ?></td>
                <td><?= htmlspecialchars($row['nama_vendor']); ?></td>
                <td><?= number_format($row['total_jam'], 1, ',', '.'); ?></td>
                <td><?= number_format($row['total_biaya'], 0, ',', '.'); ?></td>
                <td><?= number_format($row['gaji_pokok'], 0, ',', '.'); ?></td>
                <td><?= number_format($persen, 2, ',', '.'); ?>%</td>
                <td><?= $row['ranking']; ?></td>
                <td><?= number_format($avgOvt, 2, ',', '.'); ?></td>
            </tr>
            <?php endwhile; ?>
        </tbody>

    </table>
</div>

<!-- DataTables -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
<script>
$(document).ready(function(){
    var t = $('#datatable').DataTable({
        "lengthChange": false,
        "order": [[8, 'asc']], // default sort by Rank
        "columnDefs": [
            { "orderable": false, "targets": 0 } // No tidak bisa diurutkan
        ],
        "drawCallback": function(settings) {
            var api = this.api();
            api.column(0, {search:'applied', order:'applied'}).nodes().each(function(cell, i){
                cell.innerHTML = i+1; // reset nomor urut setiap kali render
            });
        }
    });
});
</script>

