<?php
include '../koneksi.php';
include '../sidebar.php';

$bulan = isset($_GET['bulan']) ? $_GET['bulan'] : date('n');
$tahun = isset($_GET['tahun']) ? $_GET['tahun'] : date('Y');

$sql = "SELECT od.id_detail, od.id_nik, k.nama, od.tanggal, 
               od.jam_in, od.jam_out, od.total_jam, od.biaya,
               COALESCE(r.nama_reason, '-') AS alasan_lembur
        FROM overtime_detail od
        JOIN karyawan k ON od.id_nik = k.id_nik
        LEFT JOIN reason r ON od.reason_id = r.reason_id
        WHERE MONTH(od.tanggal) = ? AND YEAR(od.tanggal) = ?
        ORDER BY od.tanggal ASC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $bulan, $tahun);
$stmt->execute();
$result = $stmt->get_result();
?>

<style>
.main-content {
    margin-left: 220px; /* geser isi agar tidak ketimpa sidebar */
    padding: 20px;
}
</style>

<div class="main-content">
    <h3>Laporan Overtime Detail</h3>

    <!-- Filter -->
    <form method="get" class="row mb-3">
        <div class="col-md-3">
            <select name="bulan" class="form-control">
                <?php 
                for ($i = 1; $i <= 12; $i++) {
                    $selected = ($i == $bulan) ? "selected" : "";
                    echo "<option value='$i' $selected>".date("F", mktime(0,0,0,$i,1))."</option>";
                }
                ?>
            </select>
        </div>
        <div class="col-md-2">
            <select name="tahun" class="form-control">
                <?php 
                $tahunSekarang = date('Y');
                for ($i = $tahunSekarang-5; $i <= $tahunSekarang+1; $i++) {
                    $selected = ($i == $tahun) ? "selected" : "";
                    echo "<option value='$i' $selected>$i</option>";
                }
                ?>
            </select>
        </div>
        <div class="col-md-2">
            <button type="submit" class="btn btn-primary">Filter</button>
            <a href="laporan_detail.php" class="btn btn-secondary">Reset</a>
        </div>
        <div class="col-md-3">
            <a href="../proses/generate_overtime.php?bulan=<?= $bulan; ?>&tahun=<?= $tahun; ?>" 
               class="btn btn-success">
               🔄 Generate Overtime
            </a>
        </div>
    </form>

    <a href="../proses/export_laporan.php?bulan=<?= $bulan; ?>&tahun=<?= $tahun; ?>" 
   class="btn btn-success">Export All to Excel</a>


    <?php if (isset($_GET['msg']) && $_GET['msg'] == 'generated'): ?>
        <div class="alert alert-success">✅ Data overtime berhasil digenerate!</div>
    <?php endif; ?>

    <!-- Tabel -->
    <table id="datatable" class="table table-bordered table-striped text-start">
        <thead class="table-dark">
            <tr>
                <th>No</th>
                <th>NIK</th>
                <th>Nama</th>
                <th>Tanggal</th>
                <th>Jam In</th>
                <th>Jam Out</th>
                <th>Total Jam</th>
                <th>Biaya</th>
                <th>Alasan Lembur</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td></td>
                <td><?= htmlspecialchars($row['id_nik']); ?></td>
                <td><?= htmlspecialchars($row['nama']); ?></td>
                <td><?= htmlspecialchars($row['tanggal']); ?></td>
                <td><?= htmlspecialchars($row['jam_in']); ?></td>
                <td><?= htmlspecialchars($row['jam_out']); ?></td>
                <td><?= number_format($row['total_jam'], 2, ',', '.'); ?></td>
                <td><?= number_format($row['biaya'], 0, ',', '.'); ?></td>
                <td><?= htmlspecialchars($row['alasan_lembur']); ?></td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<!-- DataTables -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
<script>
$(document).ready(function(){
    var t = $('#datatable').DataTable({
"lengthChange": false,
        "columnDefs": [
            { "orderable": false, "targets": 0 }
        ],
        "order": [[1, 'asc']]
    });

    t.on('order.dt search.dt', function(){
        let i = 1;
        t.cells(null, 0, {search:'applied', order:'applied'}).every(function(){
            this.data(i++);
        });
    }).draw();
});
</script>
