<?php
$current_page = basename($_SERVER['PHP_SELF']);

// Array halaman untuk collapse menu
$master_pages = array('karyawan_list.php', 'user_list.php', 'jam_kerja_list.php', 'reason_list.php', 'departemen_list.php', 'vendor_list.php', 'gaji_pokok_list.php');
$absensi_pages = array('tambah_absensi.php', 'daftar_absensi.php');
$overtime_pages = array('daftar_overtime.php','tambah_overtime.php','edit_overtime.php');
$laporan_pages = array('laporan_absensi.php', 'laporan_detail.php', 'laporan_rekap.php');




// Status collapse
$master_show = in_array($current_page, $master_pages) ? 'show' : '';
$absensi_show = in_array($current_page, $absensi_pages) ? 'show' : '';
$overtime_show = in_array($current_page, $overtime_pages) ? 'show' : '';
$laporan_show = in_array($current_page, $laporan_pages) ? 'show' : '';
?>

<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<!-- Sidebar -->
<div class="d-flex flex-column flex-shrink-0 p-3 bg-dark text-white" style="width: 220px; height: 100vh; position: fixed; top: 0; left: 0;">

  <!-- Logo -->
  <div class="text-center mb-3">
    <img src="/SISTEM INFORMASI ABSENSI/assets/img/logo_indofood.png" alt="Logo" style="max-width: 80%; height: auto; margin-top: 20px;">
  </div>

  <hr>

  <ul class="nav nav-pills flex-column mb-auto">

    <!-- Dashboard -->
    <li class="nav-item">
      <a href="/SISTEM INFORMASI ABSENSI/dashboard.php" class="nav-link text-white <?php echo $current_page == 'dashboard.php' ? 'active' : ''; ?>">
        <i class="bi bi-speedometer2"></i> Dashboard
      </a>
    </li>

    <!-- Master Data -->
    <li>
      <a class="nav-link text-white d-flex justify-content-between align-items-center <?php echo $master_show ? '' : 'collapsed'; ?>" 
         data-bs-toggle="collapse" href="#masterData" role="button" aria-expanded="<?php echo $master_show ? 'true' : 'false'; ?>" aria-controls="masterData">
        <span><i class="bi bi-folder"></i> Master Data</span>
        <i class="bi bi-caret-down-fill"></i>
      </a>
      <div class="collapse ps-3 <?php echo $master_show; ?>" id="masterData">
        <ul class="nav flex-column">
          <li><a href="/SISTEM INFORMASI ABSENSI/master_data/karyawan/karyawan_list.php" class="nav-link text-white <?php echo $current_page == 'karyawan_list.php' ? 'active' : ''; ?>">Data Karyawan</a></li>
          <li><a href="/SISTEM INFORMASI ABSENSI/master_data/user/user_list.php" class="nav-link text-white <?php echo $current_page == 'user_list.php' ? 'active' : ''; ?>">Data User</a></li>
          <li><a href="/SISTEM INFORMASI ABSENSI/master_data/jam_kerja/jam_kerja_list.php" class="nav-link text-white <?php echo $current_page == 'jam_kerja_list.php' ? 'active' : ''; ?>">Data Jam Kerja</a></li>
          <li><a href="/SISTEM INFORMASI ABSENSI/master_data/reason/reason_list.php" class="nav-link text-white <?php echo $current_page == 'reason_list.php' ? 'active' : ''; ?>">Data Alasan Lembur</a></li>
          <li><a href="/SISTEM INFORMASI ABSENSI/master_data/departemen/departemen_list.php" class="nav-link text-white <?php echo $current_page == 'departemen_list.php' ? 'active' : ''; ?>">Data Departemen</a></li>
          <li><a href="/SISTEM INFORMASI ABSENSI/master_data/vendor/vendor_list.php" class="nav-link text-white <?php echo $current_page == 'vendor_list.php' ? 'active' : ''; ?>">Data Vendor</a></li>
          <li><a href="/SISTEM INFORMASI ABSENSI/master_data/gaji_pokok/gaji_pokok_list.php" class="nav-link text-white <?php echo $current_page == 'gaji_pokok_list.php' ? 'active' : ''; ?>">Data Gaji Pokok</a></li>
        </ul>
      </div>
    </li>

    <!-- Absensi -->
    <li>
      <a class="nav-link text-white d-flex justify-content-between align-items-center <?php echo $absensi_show ? '' : 'collapsed'; ?>" 
         data-bs-toggle="collapse" href="#absensi" role="button" aria-expanded="<?php echo $absensi_show ? 'true' : 'false'; ?>" aria-controls="absensi">
        <span><i class="bi bi-calendar-check"></i> Absensi</span>
        <i class="bi bi-caret-down-fill"></i>
      </a>
      <div class="collapse ps-3 <?php echo $absensi_show; ?>" id="absensi">
        <ul class="nav flex-column">
          <li><a href="/SISTEM INFORMASI ABSENSI/absensi/tambah_absensi.php" class="nav-link text-white <?php echo $current_page == 'tambah_absensi.php' ? 'active' : ''; ?>">Tambah Absensi</a></li>
          <li><a href="/SISTEM INFORMASI ABSENSI/absensi/daftar_absensi.php" class="nav-link text-white <?php echo $current_page == 'daftar_absensi.php' ? 'active' : ''; ?>">Daftar Absensi</a></li>
        </ul>
      </div>
    </li>

    <!-- Work Schedule Overtime -->
    <li>
      <a class="nav-link text-white d-flex justify-content-between align-items-center <?php echo $overtime_show ? '' : 'collapsed'; ?>" 
         data-bs-toggle="collapse" href="#planOvertime" role="button" aria-expanded="<?php echo $overtime_show ? 'true' : 'false'; ?>" aria-controls="planOvertime">
        <span><i class="bi bi-clock-history"></i> Work Schedule Overtime</span>
        <i class="bi bi-caret-down-fill"></i>
      </a>
      <div class="collapse ps-3 <?php echo $overtime_show; ?>" id="planOvertime">
        <ul class="nav flex-column">
          <li><a href="/SISTEM INFORMASI ABSENSI/plan_overtime/daftar_overtime.php" class="nav-link text-white <?php echo $current_page=='daftar_overtime.php'?'active':'' ?>">Daftar Plan Overtime</a></li>
          <li><a href="/SISTEM INFORMASI ABSENSI/plan_overtime/tambah_overtime.php" class="nav-link text-white <?php echo $current_page=='tambah_overtime.php'?'active':'' ?>">Tambah Plan Overtime</a></li>
        </ul>
      </div>
    </li>

<!-- Laporan -->
<li>
  <a class="nav-link text-white d-flex justify-content-between align-items-center <?php echo $laporan_show ? '' : 'collapsed'; ?>" 
     data-bs-toggle="collapse" href="#laporanMenu" role="button" aria-expanded="<?php echo $laporan_show ? 'true' : 'false'; ?>" aria-controls="laporanMenu">
    <span><i class="bi bi-graph-up"></i> Laporan</span>
    <i class="bi bi-caret-down-fill"></i>
  </a>
  <div class="collapse ps-3 <?php echo $laporan_show; ?>" id="laporanMenu">
    <ul class="nav flex-column">
      <li>
        <a href="/SISTEM INFORMASI ABSENSI/laporan/laporan_absensi.php" 
           class="nav-link text-white <?php echo $current_page == 'laporan_absensi.php' ? 'active' : ''; ?>">
           Laporan Absensi
        </a>
      </li>
      <li>
        <a href="/SISTEM INFORMASI ABSENSI/laporan/laporan_detail.php" 
           class="nav-link text-white <?php echo $current_page == 'laporan_detail.php' ? 'active' : ''; ?>">
           Laporan Overtime Detail
        </a>
      </li>
      <li>
        <a href="/SISTEM INFORMASI ABSENSI/laporan/laporan_rekap.php" 
           class="nav-link text-white <?php echo $current_page == 'laporan_rekap.php' ? 'active' : ''; ?>">
           Laporan Overtime Rekap
        </a>
      </li>
    </ul>
  </div>
</li>


    <!-- Logout -->
    <li>
      <a href="/SISTEM INFORMASI ABSENSI/logout.php" class="nav-link text-white">
        <i class="bi bi-box-arrow-right"></i> Logout
      </a>
    </li>

  </ul>
</div>

<!-- SweetAlert2 Logout -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
document.addEventListener("DOMContentLoaded", function() {
    const logoutLink = document.querySelector('a[href="/SISTEM INFORMASI ABSENSI/logout.php"]');
    if (logoutLink) {
        logoutLink.addEventListener("click", function(e) {
            e.preventDefault();
            Swal.fire({
                title: 'Konfirmasi Logout',
                text: "Apakah Anda yakin ingin keluar dari sistem?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Ya, Keluar',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = logoutLink.getAttribute("href");
                }
            });
        });
    }
});
</script>
