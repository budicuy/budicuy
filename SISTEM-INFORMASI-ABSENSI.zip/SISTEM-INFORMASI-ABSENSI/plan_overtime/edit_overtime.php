<?php
include '../koneksi.php';
include '../sidebar.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) { die('ID tidak valid'); }

/* Dropdown data */
$karyawan = mysqli_query($conn, "
  SELECT k.id_nik, k.nama, d.nama_departemen, v.nama_vendor
  FROM karyawan k
  LEFT JOIN departemen d ON k.id_dept = d.id_dept
  LEFT JOIN vendor v     ON k.id_vendor = v.id_vendor
  ORDER BY k.id_nik ASC
");
$reasons = mysqli_query($conn, "SELECT reason_id, nama_reason FROM reason ORDER BY nama_reason ASC");
$shifts  = mysqli_query($conn, "SELECT * FROM jam_kerja ORDER BY kode_shift ASC");

/* Data existing (join supaya Nama/Vendor/Dept bisa diisi awal) */
$stmt = $conn->prepare("
  SELECT po.*, k.nama, d.nama_departemen, v.nama_vendor
  FROM plan_overtime po
  LEFT JOIN karyawan k ON po.nik = k.id_nik
  LEFT JOIN departemen d ON k.id_dept = d.id_dept
  LEFT JOIN vendor v ON k.id_vendor = v.id_vendor
  WHERE po.id = ?
");
$stmt->bind_param('i', $id);
$stmt->execute();
$data = $stmt->get_result()->fetch_assoc();
if (!$data) { die('Data tidak ditemukan'); }

/* Submit */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $nik           = $_POST['nik']            ?? '';
  $tanggal       = $_POST['tanggal']        ?? '';
  $kode_shift    = $_POST['kode_shift']     ?? '';
  $jam_in        = $_POST['jam_in']         ?? '';
  $jam_out       = $_POST['jam_out']        ?? '';
  $reason_id     = isset($_POST['reason_id']) ? (int)$_POST['reason_id'] : 0;
  $overtime_type = $_POST['overtime_type']  ?? '';
  $description   = $_POST['description']    ?? '';

  if ($nik==='' || $tanggal==='' || $kode_shift==='' || $jam_in==='' || $jam_out==='' || $reason_id===0) {
    echo "<script>alert('Lengkapi isian wajib!');history.back();</script>"; exit;
  }

  // hitung total_jam (support lewat tengah malam)
  $start = strtotime($tanggal.' '.$jam_in);
  $end   = strtotime($tanggal.' '.$jam_out);
  if ($end <= $start) { $end = strtotime($tanggal.' '.$jam_out.' +1 day'); }
  $total_jam = ($end - $start) / 3600.0;

  // update sesuai kolom tabel plan_overtime
  $u = $conn->prepare("
    UPDATE plan_overtime
       SET nik=?, tanggal=?, kode_shift=?, jam_in=?, jam_out=?, total_jam=?, reason_id=?, overtime_type=?, description=?
     WHERE id=?
  ");
  $u->bind_param(
    "sssssdissi",
    $nik, $tanggal, $kode_shift, $jam_in, $jam_out, $total_jam, $reason_id, $overtime_type, $description, $id
  );

  if ($u->execute()) {
    echo "<script>alert('Plan Overtime berhasil diperbarui');window.location='daftar_overtime.php';</script>"; exit;
  } else {
    echo "Error: ".$u->error;
  }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Edit Plan Overtime</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
  .content { margin-left:240px; padding:20px; }
</style>
</head>
<body>
<div class="content">
  <div class="container-fluid">
    <h4 class="mb-4">Form Edit Work Schedule Overtime</h4>

    <form method="post">
      <div class="row g-3">
        <!-- Pilih Karyawan -->
        <div class="col-md-3">
          <label class="form-label">Pilih Karyawan</label>
          <select name="nik" id="nik" class="form-control" required>
            <option value="">-- Pilih --</option>
            <?php while ($k = mysqli_fetch_assoc($karyawan)) {
              $sel = ($k['id_nik'] === ($data['nik'] ?? '')) ? 'selected' : '';
              $dept_label   = $k['nama_departemen'] ?: '-';
              $vendor_label = $k['nama_vendor'] ?: '-';
            ?>
              <option value="<?= htmlspecialchars($k['id_nik']) ?>" <?= $sel ?>
                      data-nama="<?= htmlspecialchars($k['nama']) ?>"
                      data-dept="<?= htmlspecialchars($dept_label) ?>"
                      data-vendor="<?= htmlspecialchars($vendor_label) ?>">
                <?= htmlspecialchars($k['id_nik'].' - '.$k['nama'].' ('.$vendor_label.' - '.$dept_label.')') ?>
              </option>
            <?php } ?>
          </select>
        </div>

        <div class="col-md-3">
          <label class="form-label">Nama</label>
          <input type="text" id="nama" class="form-control bg-light"
                 value="<?= htmlspecialchars($data['nama'] ?? '') ?>" readonly>
        </div>
        <div class="col-md-3">
          <label class="form-label">Vendor</label>
          <input type="text" id="vendor" class="form-control bg-light"
                 value="<?= htmlspecialchars($data['nama_vendor'] ?? '') ?>" readonly>
        </div>
        <div class="col-md-3">
          <label class="form-label">Departemen</label>
          <input type="text" id="departemen" class="form-control bg-light"
                 value="<?= htmlspecialchars($data['nama_departemen'] ?? '') ?>" readonly>
        </div>

        <!-- Tanggal & Shift & Jam -->
        <div class="col-md-3">
          <label class="form-label">Tanggal Lembur</label>
          <input type="date" name="tanggal" class="form-control"
                 value="<?= htmlspecialchars($data['tanggal'] ?? '') ?>" required>
        </div>

        <div class="col-md-3">
          <label class="form-label">Shift</label>
          <select name="kode_shift" class="form-control" required>
            <option value="">-- Pilih Shift --</option>
            <?php while ($s = mysqli_fetch_assoc($shifts)) { ?>
              <option value="<?= htmlspecialchars($s['kode_shift']) ?>"
                <?= ($s['kode_shift'] === ($data['kode_shift'] ?? '')) ? 'selected' : '' ?>>
                <?= htmlspecialchars($s['kode_shift']." (".$s['jam_masuk']." - ".$s['jam_keluar'].")") ?>
              </option>
            <?php } ?>
          </select>
        </div>

        <div class="col-md-3">
          <label class="form-label">Jam Mulai</label>
          <input type="time" name="jam_in" class="form-control"
                 value="<?= htmlspecialchars($data['jam_in'] ?? '') ?>" required>
        </div>
        <div class="col-md-3">
          <label class="form-label">Jam Selesai</label>
          <input type="time" name="jam_out" class="form-control"
                 value="<?= htmlspecialchars($data['jam_out'] ?? '') ?>" required>
        </div>

        <!-- Reason + Jenis + Deskripsi -->
        <div class="col-md-3">
          <label class="form-label">Reason</label>
          <select name="reason_id" class="form-control" required>
            <option value="">-- Pilih Reason --</option>
            <?php mysqli_data_seek($reasons, 0); while ($r = mysqli_fetch_assoc($reasons)) { ?>
              <option value="<?= (int)$r['reason_id'] ?>"
                <?= ((int)$r['reason_id'] === (int)($data['reason_id'] ?? 0)) ? 'selected' : '' ?>>
                <?= htmlspecialchars($r['nama_reason']) ?>
              </option>
            <?php } ?>
          </select>
        </div>

        <div class="col-md-3">
          <label class="form-label">Jenis Overtime</label>
          <input type="text" name="overtime_type" class="form-control"
                 value="<?= htmlspecialchars($data['overtime_type'] ?? '') ?>"
                 placeholder="Contoh: Regular / Weekend">
        </div>

        <div class="col-md-6">
          <label class="form-label">Deskripsi</label>
          <textarea name="description" class="form-control" rows="3"
                    placeholder="Uraian pekerjaan"><?= htmlspecialchars($data['description'] ?? '') ?></textarea>
        </div>
      </div>

      <div class="mt-4 d-flex gap-2">
        <button class="btn btn-warning" type="submit">Update</button>
        <a href="daftar_overtime.php" class="btn btn-secondary">Kembali</a>
      </div>
    </form>
  </div>
</div>

<script>
function fillInfoFromSelect(sel){
  const opt = sel.options[sel.selectedIndex];
  document.getElementById('nama').value      = opt.getAttribute('data-nama')   || '';
  document.getElementById('departemen').value= opt.getAttribute('data-dept')   || '';
  document.getElementById('vendor').value    = opt.getAttribute('data-vendor') || '';
}
document.addEventListener('DOMContentLoaded', ()=>{
  const nik = document.getElementById('nik');
  nik.addEventListener('change', ()=> fillInfoFromSelect(nik));
});
</script>
</body>
</html>
