<?php
include '../koneksi.php';
include '../sidebar.php';

// Ambil data dropdown karyawan + departemen + vendor
$karyawan = mysqli_query($conn, "
    SELECT k.id_nik, k.nama, d.nama_departemen, v.nama_vendor
    FROM karyawan k
    LEFT JOIN departemen d ON k.id_dept = d.id_dept
    LEFT JOIN vendor v ON k.id_vendor = v.id_vendor
    ORDER BY k.id_nik ASC
");
$reasons  = mysqli_query($conn, "SELECT reason_id, nama_reason FROM reason ORDER BY nama_reason ASC");
$shifts   = mysqli_query($conn, "SELECT * FROM jam_kerja ORDER BY kode_shift ASC");

// Submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nik           = $_POST['nik'] ?? '';
    $tanggal       = $_POST['tanggal'] ?? '';
    $jam_in        = $_POST['jam_in'] ?? '';
    $jam_out       = $_POST['jam_out'] ?? '';
    $kode_shift    = $_POST['kode_shift'] ?? '';
    $reason_id     = isset($_POST['reason_id']) ? (int)$_POST['reason_id'] : 0;
    $overtime_type = $_POST['overtime_type'] ?? 'Regular';
    $description   = $_POST['description'] ?? '';

    if ($nik === '' || $tanggal === '' || $jam_in === '' || $jam_out === '' || $kode_shift === '' || $reason_id === 0) {
        echo "<script>alert('Lengkapi isian wajib!');history.back();</script>";
        exit;
    }

    $start = strtotime($tanggal . ' ' . $jam_in);
    $end   = strtotime($tanggal . ' ' . $jam_out);
    if ($end <= $start) {
        $end = strtotime($tanggal . ' ' . $jam_out . ' +1 day');
    }
    $total_jam = ($end - $start) / 3600.0;

    $stmt = $conn->prepare("INSERT INTO plan_overtime 
        (nik, tanggal, kode_shift, jam_in, jam_out, total_jam, reason_id, overtime_type, description, status) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Planned')");
    $stmt->bind_param("sssssdiss", $nik, $tanggal, $kode_shift, $jam_in, $jam_out, $total_jam, $reason_id, $overtime_type, $description);

    if ($stmt->execute()) {
        echo "<script>alert('Plan Overtime berhasil ditambahkan');window.location='daftar_overtime.php';</script>";
        exit;
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Tambah Plan Overtime</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<style>.content{margin-left:240px;padding:20px}</style>
</head>
<body>
<div class="content">
  <div class="container-fluid">
    <h4 class="mb-4">Form Tambah Work Schedule Overtime</h4>

    <form method="post">
      <div class="row g-3">
        <!-- Pilih Karyawan -->
        <div class="col-md-6">
          <label class="form-label">Pilih Karyawan</label>
          <select name="nik" id="nik" class="form-control select2" required>
            <option value="">-- Pilih Karyawan --</option>
            <?php while ($k = mysqli_fetch_assoc($karyawan)) {
                $dept_label   = $k['nama_departemen'] ?: '-';
                $vendor_label = $k['nama_vendor'] ?: '-';
            ?>
            <option value="<?= htmlspecialchars($k['id_nik']) ?>"
                    data-nama="<?= htmlspecialchars($k['nama']) ?>"
                    data-dept="<?= htmlspecialchars($dept_label) ?>"
                    data-vendor="<?= htmlspecialchars($vendor_label) ?>">
              <?= htmlspecialchars($k['id_nik'].' - '.$k['nama'].' ('.$vendor_label.' - '.$dept_label.')') ?>
            </option>
            <?php } ?>
          </select>
        </div>

        <div class="col-md-2">
          <label class="form-label">Nama</label>
          <input type="text" id="nama" class="form-control bg-light" readonly>
        </div>
        <div class="col-md-2">
          <label class="form-label">Vendor</label>
          <input type="text" id="vendor" class="form-control bg-light" readonly>
        </div>
        <div class="col-md-2">
          <label class="form-label">Departemen</label>
          <input type="text" id="departemen" class="form-control bg-light" readonly>
        </div>

        <!-- Tanggal & Shift & Jam -->
        <div class="col-md-3">
          <label class="form-label">Tanggal Lembur</label>
          <input type="date" name="tanggal" class="form-control" required>
        </div>

        <div class="col-md-3">
          <label class="form-label">Shift</label>
          <select name="kode_shift" class="form-control" required>
            <option value="">-- Pilih Shift --</option>
            <?php while ($s = mysqli_fetch_assoc($shifts)) { ?>
              <option value="<?= htmlspecialchars($s['kode_shift']) ?>">
                <?= htmlspecialchars($s['kode_shift']." (".$s['jam_masuk']." - ".$s['jam_keluar'].")") ?>
              </option>
            <?php } ?>
          </select>
        </div>

        <div class="col-md-3">
          <label class="form-label">Jam Mulai</label>
          <input type="time" name="jam_in" class="form-control" required>
        </div>
        <div class="col-md-3">
          <label class="form-label">Jam Selesai</label>
          <input type="time" name="jam_out" class="form-control" required>
        </div>

        <!-- Reason + Jenis + Deskripsi -->
        <div class="col-md-3">
          <label class="form-label">Reason</label>
          <select name="reason_id" class="form-control" required>
            <option value="">-- Pilih Reason --</option>
            <?php while ($r = mysqli_fetch_assoc($reasons)) { ?>
              <option value="<?= (int)$r['reason_id'] ?>"><?= htmlspecialchars($r['nama_reason']) ?></option>
            <?php } ?>
          </select>
        </div>

        <div class="col-md-3">
          <label class="form-label">Jenis Overtime</label>
          <input type="text" name="overtime_type" class="form-control" placeholder="Contoh: Regular / Weekend">
        </div>

        <div class="col-md-6">
          <label class="form-label">Deskripsi</label>
          <textarea name="description" class="form-control" rows="3" placeholder="Uraian pekerjaan"></textarea>
        </div>
      </div>

      <div class="mt-4 d-flex gap-2">
        <button type="submit" class="btn btn-success">Simpan</button>
        <a href="daftar_overtime.php" class="btn btn-secondary">Kembali</a>
      </div>
    </form>
  </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
$(document).ready(function() {
  // Inisialisasi Select2 dengan search/autocomplete
  $('#nik').select2({
    placeholder: "-- Pilih Karyawan --",
    allowClear: true,
    width: '100%',
    templateSelection: function(data, container) {
      var opt = $('#nik option[value="'+data.id+'"]');
      if(opt.length > 0 && data.id !== ""){
        return opt.val(); // tampilkan hanya NIK
      }
      return data.text;
    }
  });

  // Update field Nama, Vendor, Departemen saat dipilih
  $('#nik').on('select2:select', function(e){
    var data = e.params.data;
    var opt = $('#nik option[value="'+data.id+'"]');
    $('#nama').val(opt.data('nama') || '');
    $('#departemen').val(opt.data('dept') || '');
    $('#vendor').val(opt.data('vendor') || '');
  });

  // Clear field saat dipilih kosong
  $('#nik').on('select2:clear', function(){
    $('#nama').val('');
    $('#departemen').val('');
    $('#vendor').val('');
  });
});
</script>
</body>
</html>
