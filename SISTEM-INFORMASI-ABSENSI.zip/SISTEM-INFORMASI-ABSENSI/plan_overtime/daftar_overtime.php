<?php
session_start();
include '../koneksi.php';


$user_role = $_SESSION['role'] ?? 'karyawan';

// --- Filter tanggal ---
$start_date = $_GET['start_date'] ?? '';
$end_date   = $_GET['end_date'] ?? '';

// --- Update status jika tombol Accept diklik ---
if(isset($_GET['accept_id']) && in_array($user_role, ['admin','manager'])){
    $id_accept = intval($_GET['accept_id']);
    $update_sql = "UPDATE plan_overtime SET status='Approved' WHERE id=$id_accept";
    mysqli_query($conn,$update_sql);
    header("Location: daftar_overtime.php?start_date=$start_date&end_date=$end_date");
    exit;
}

// --- Hapus banyak data ---
if(isset($_POST['delete_selected']) && isset($_POST['ids'])){
    $ids = array_map('intval', $_POST['ids']);
    if(count($ids) > 0){
        $id_list = implode(",", $ids);
        $delete_sql = "DELETE FROM plan_overtime WHERE id IN ($id_list)";
        mysqli_query($conn,$delete_sql);
    }
    header("Location: daftar_overtime.php?start_date=$start_date&end_date=$end_date");
    exit;
}

// --- Query daftar overtime ---
$where = "";
if ($start_date && $end_date) {
  $where = "WHERE po.tanggal BETWEEN '".mysqli_real_escape_string($conn,$start_date)."' 
                             AND '".mysqli_real_escape_string($conn,$end_date)."'";
}

$sql = "SELECT po.*, k.nama, d.nama_departemen, v.nama_vendor, 
               r.nama_reason, j.jam_masuk, j.jam_keluar
        FROM plan_overtime po
        LEFT JOIN karyawan k ON po.nik = k.id_nik
        LEFT JOIN departemen d ON k.id_dept = d.id_dept
        LEFT JOIN vendor v ON k.id_vendor = v.id_vendor
        LEFT JOIN reason r ON po.reason_id = r.reason_id
        LEFT JOIN jam_kerja j ON po.kode_shift = j.kode_shift
        $where
        ORDER BY po.tanggal DESC";

$result = mysqli_query($conn, $sql);

include '../sidebar.php';

?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Daftar Plan Overtime</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
<style>
  .content { margin-left:240px; padding:20px; }
  table.dataTable th, table.dataTable td { white-space: normal; vertical-align: middle; }
  td, th { font-size: 0.85rem; }
  .badge { font-size: 0.75rem; }
</style>
</head>
<body>
<div class="content">
  <div class="container-fluid">

    <h4 class="mb-4 fw-bold">WORK SCHEDULE OVERTIME</h4>

    <!-- Filter -->
    <div class="p-3 mb-3 bg-light rounded shadow-sm">
      <form method="get" class="row g-2 align-items-center">
        <div class="col-md-3">
          <input type="date" name="start_date" class="form-control" value="<?= htmlspecialchars($start_date) ?>">
        </div>
        <div class="col-md-3">
          <input type="date" name="end_date" class="form-control" value="<?= htmlspecialchars($end_date) ?>">
        </div>
        <div class="col-md-6 d-flex gap-2">
          <button class="btn btn-primary">Filter</button>
          <a href="daftar_overtime.php" class="btn btn-secondary">Reset</a>
          <a href="tambah_overtime.php" class="btn btn-success ms-auto">+ Tambah Plan Overtime</a>
        </div>
      </form>
    </div>

    <!-- Form untuk hapus banyak -->
    <form method="post" id="formDelete">
      <div class="mb-2">
        <button type="submit" name="delete_selected" class="btn btn-danger btn-sm"
                onclick="return confirm('Apakah yakin ingin menghapus data yang dipilih?')">
          Hapus yang dipilih
        </button>
      </div>

      <!-- Tabel -->
      <div class="table-responsive shadow-sm">
        <table class="table table-bordered table-striped table-hover table-sm align-middle" id="tableOvertime">
          <thead class="table-dark text-center">
            <tr>
              <th><input type="checkbox" id="selectAll"></th>
              <th>No</th>
              <th>Tanggal</th>
              <th>NIK</th>
              <th>Nama</th>
              <th>Vendor</th>
              <th>Dept</th>
              <th>Shift</th>
              <th>Mulai</th>
              <th>Selesai</th>
              <th>Durasi</th>
              <th>Reason</th>
              <th>Jenis</th>
              <th>Deskripsi</th>
              <th>Status</th>
              <th>Aksi</th>
            </tr>
          </thead>
        <tbody>
        <?php $no=1; while($row = mysqli_fetch_assoc($result)) { ?>
          <tr>
            <td class="text-center">
              <input type="checkbox" name="ids[]" value="<?= $row['id'] ?>">
            </td>
            <td class="text-center"><?= $no++ ?></td>
            <td><?= htmlspecialchars($row['tanggal'] ?? '') ?></td>
            <td><?= htmlspecialchars($row['nik'] ?? '') ?></td>
            <td><?= htmlspecialchars($row['nama'] ?? '') ?></td>
            <td><?= htmlspecialchars($row['nama_vendor'] ?? '') ?></td>
            <td><?= htmlspecialchars($row['nama_departemen'] ?? '') ?></td>
            <td>
              <?php 
                $shift = $row['kode_shift'] ?? '';
                $masuk = !empty($row['jam_masuk']) ? date('H:i', strtotime($row['jam_masuk'])) : '--:--';
                $keluar = !empty($row['jam_keluar']) ? date('H:i', strtotime($row['jam_keluar'])) : '--:--';
                echo htmlspecialchars($shift . " ($masuk-$keluar)");
              ?>
            </td>
            <td class="text-center"><?= htmlspecialchars($row['jam_in'] ?? '') ?></td>
            <td class="text-center"><?= htmlspecialchars($row['jam_out'] ?? '') ?></td>
            <td class="text-center"><?= number_format($row['total_jam'] ?? 0,2) ?></td>
            <td><?= htmlspecialchars($row['nama_reason'] ?? '') ?></td>
            <td><?= htmlspecialchars($row['overtime_type'] ?? '') ?></td>
            <td><?= htmlspecialchars($row['description'] ?? '') ?></td>
            <td class="text-center">
              <span class="badge 
                    <?php if(($row['status'] ?? '')=='Planned') echo 'bg-warning text-dark';
                          elseif(($row['status'] ?? '')=='Approved') echo 'bg-success';
                          else echo 'bg-danger'; ?>">
              <?= htmlspecialchars($row['status'] ?? '') ?>
              </span>
            </td>
            <td class="text-center">
              <a href="edit_overtime.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
              <a href="hapus_overtime.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Apakah yakin ingin dihapus?')">Hapus</a>
              <?php if(($row['status']=='Planned') && in_array($user_role,['admin','manager'])): ?>
                <a href="?accept_id=<?= $row['id'] ?>&start_date=<?= $start_date ?>&end_date=<?= $end_date ?>" 
                   class="btn btn-sm btn-success" onclick="return confirm('Apakah yakin ingin approve overtime ini?')">Accept</a>
              <?php endif; ?>
            </td>
          </tr>
        <?php } ?>
        </tbody>
      </table>
    </div>
    </form>

  </div>
</div>

<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
$(document).ready(function() {
    $('#tableOvertime').DataTable({
        "columnDefs": [
            { "orderable": false, "targets": [0, 15] }
        ],
        "order": [[2,"desc"]]
    });

    // Select/Deselect semua checkbox
    $('#selectAll').click(function() {
        $('input[name="ids[]"]').prop('checked', this.checked);
    });
});
</script>
</body>
</html>
