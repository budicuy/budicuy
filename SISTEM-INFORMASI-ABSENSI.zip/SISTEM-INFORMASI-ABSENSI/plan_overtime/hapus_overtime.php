<?php
include '../koneksi.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id<=0) { die('ID tidak valid'); }

$stmt = mysqli_prepare($conn, "DELETE FROM plan_overtime WHERE id=?");
mysqli_stmt_bind_param($stmt, 'i', $id);
if (mysqli_stmt_execute($stmt)) {
  header("Location: daftar_overtime.php");
  exit;
} else {
  echo "Error: ".mysqli_stmt_error($stmt);
}
