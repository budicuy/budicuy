<?php
include '../../koneksi.php';
include '../../sidebar.php';

// Ambil data departemen urut berdasarkan nama
$result = mysqli_query($conn, "SELECT * FROM departemen ORDER BY nama_departemen ASC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Data Departemen</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- DataTables CSS -->
  <link href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" rel="stylesheet">
  <style>
    .main-content { margin-left: 220px; padding: 30px; }
  </style>
</head>
<body>
<div class="main-content">
  <div>
    <div>
      <h2 class="mb-4">DATA DEPARTEMEN</h2>
      <a href="tambah_departemen.php" class="btn btn-success mb-3">+ Tambah Departemen</a>
      
      <div class="table-responsive">
        <table id="departemenTable" class="table table-bordered table-striped align-middle">
          <thead class="table-dark text-center">
            <tr>
              <th style="width:50px;">No</th>
              <th>Nama Departemen</th>
              <th style="width:180px;">Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php while($row=mysqli_fetch_assoc($result)) { ?>
              <tr>
                <td></td> <!-- Auto isi nomor oleh DataTables -->
                <td><?= $row['nama_departemen']; ?></td>
                <td class="text-center">
                  <a href="edit_departemen.php?id=<?= $row['id_dept']; ?>" class="btn btn-warning btn-sm">Edit</a>
                  <a href="hapus_departemen.php?id=<?= $row['id_dept']; ?>" 
                     onclick="return confirm('Yakin hapus departemen ini?')" 
                     class="btn btn-danger btn-sm">Hapus</a>
                </td>
              </tr>
            <?php } ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- jQuery + DataTables -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

<script>
$(document).ready(function() {
    var t = $('#departemenTable').DataTable({
        "columnDefs": [
            { "orderable": false, "targets": 0 }, // kolom No tidak bisa diurut
            { "orderable": false, "targets": 2 }  // kolom Aksi tidak bisa diurut
        ],
        "order": [[1, 'asc']] // urut default berdasarkan Nama Departemen
    });

    // Auto numbering untuk kolom No
    t.on('order.dt search.dt', function () {
        let i = 1;
        t.cells(null, 0, {search:'applied', order:'applied'}).every(function (cell) {
            this.data(i++);
        });
    }).draw();
});
</script>
</body>
</html>
