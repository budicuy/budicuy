<?php
include '../../koneksi.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    mysqli_query($conn, "DELETE FROM departemen WHERE id_dept='$id'");
}

header("Location: departemen_list.php");
exit;
