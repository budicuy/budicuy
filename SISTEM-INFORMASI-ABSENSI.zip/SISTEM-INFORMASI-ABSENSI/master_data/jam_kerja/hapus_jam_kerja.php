<?php
include '../../koneksi.php';

$kode = $_GET['kode_shift'];
mysqli_query($conn, "DELETE FROM jam_kerja WHERE kode_shift='$kode'");

echo "<script>alert('Data berhasil dihapus!'); window.location='jam_kerja_list.php';</script>";
?>
