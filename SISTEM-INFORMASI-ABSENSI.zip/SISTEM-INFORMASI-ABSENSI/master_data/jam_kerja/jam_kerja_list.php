<?php
include '../../koneksi.php';
include '../../sidebar.php';
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Data Jam Kerja</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- DataTables CSS -->
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
  <style>
    body {
      background-color: #f8f9fa;
    }
    .main-content {
      margin-left: 220px; /* lebar sidebar */
      padding: 30px;
    }

  </style>
</head>
<body>

<div class="main-content">
  <div>
    <div>
        <h2 class="mb-4">DATA JAM KERJA</h2>
        <a href="tambah_jam_kerja.php" class="btn btn-success mb-3">+ Tambah Jam Kerja</a>

        <div class="table-responsive">
          <table id="jamKerjaTable" class="table table-striped table-bordered align-middle">
            <thead class="table-dark text-center">
              <tr>
                <th style="width:50px;">No</th>
                <th>Kode Shift</th>
                <th>Jam Masuk</th>
                <th>Jam Keluar</th>
                <th style="width:180px;">Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php
              $result = mysqli_query($conn, "SELECT * FROM jam_kerja ORDER BY kode_shift ASC");
              while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>
                        <td></td> <!-- nomor otomatis dari DataTables -->
                        <td>".$row['kode_shift']."</td>
                        <td>".$row['jam_masuk']."</td>
                        <td>".$row['jam_keluar']."</td>
                        <td class='text-center'>
                          <a href='edit_jam_kerja.php?kode_shift=".$row['kode_shift']."' class='btn btn-warning btn-sm'>Edit</a>
                          <a href='hapus_jam_kerja.php?kode_shift=".$row['kode_shift']."' class='btn btn-danger btn-sm' onclick=\"return confirm('Yakin hapus data ini?');\">Hapus</a>
                        </td>
                      </tr>";
              }
              ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

  <!-- jQuery + DataTables -->
  <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
  <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

  <script>
    $(document).ready(function () {
      var t = $('#jamKerjaTable').DataTable({
        columnDefs: [
          { targets: 0, orderable: false, searchable: false }, // No tidak bisa sort/search
          { targets: -1, orderable: false } // Aksi tidak bisa sort
        ],
        order: [[1, 'asc']] // default urut berdasarkan Kode Shift
      });

      // auto numbering untuk kolom No
      t.on('order.dt search.dt', function () {
        let i = 1;
        t.cells(null, 0, { search: 'applied', order: 'applied' }).every(function () {
          this.data(i++);
        });
      }).draw();
    });
  </script>
</body>
</html>
