<?php
include '../../koneksi.php';
include '../../sidebar.php';

if (isset($_POST['simpan'])) {
    $kode_shift = $_POST['kode_shift'];
    $jam_masuk  = $_POST['jam_masuk'];
    $jam_keluar = $_POST['jam_keluar'];

    mysqli_query($conn, "INSERT INTO jam_kerja (kode_shift, jam_masuk, jam_keluar) 
                         VALUES ('$kode_shift', '$jam_masuk', '$jam_keluar')");

    echo "<script>alert('Data jam kerja berhasil ditambahkan!'); window.location='jam_kerja_list.php';</script>";
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Tambah Jam Kerja</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .main-content { margin-left:220px; padding:30px; }
  </style>
</head>
<body>
<div class="main-content">
  <div>
    <div>
      <h2 class="mb-4">Tambah Jam Kerja</h2>
      <form method="POST">
        <div class="mb-3">
          <label class="form-label">Kode Shift</label>
          <input type="text" name="kode_shift" class="form-control" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Jam Masuk</label>
          <input type="time" name="jam_masuk" class="form-control" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Jam Keluar</label>
          <input type="time" name="jam_keluar" class="form-control" required>
        </div>
        <button type="submit" name="simpan" class="btn btn-success">Simpan</button>
        <a href="jam_kerja_list.php" class="btn btn-secondary">Batal</a>
      </form>
    </div>
  </div>
</div>
</body>
</html>
