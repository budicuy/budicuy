<?php
include '../../koneksi.php';
include '../../sidebar.php';

if (isset($_GET['kode_shift'])) {
    $kode_shift = $_GET['kode_shift'];
    $result = mysqli_query($conn, "SELECT * FROM jam_kerja WHERE kode_shift='$kode_shift'");
    $row = mysqli_fetch_assoc($result);
}

if (isset($_POST['update'])) {
    $kode_shift = $_POST['kode_shift'];
    $jam_masuk  = $_POST['jam_masuk'];
    $jam_keluar = $_POST['jam_keluar'];

    mysqli_query($conn, "UPDATE jam_kerja SET 
        jam_masuk='$jam_masuk', 
        jam_keluar='$jam_keluar' 
        WHERE kode_shift='$kode_shift'");

    echo "<script>alert('Data jam kerja berhasil diperbarui!'); window.location='jam_kerja_list.php';</script>";
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Edit Jam Kerja</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .main-content {
      margin-left: 220px; /* lebar sidebar */
      padding: 30px;
    }

  </style>
</head>
<body>
<div class="main-content">
  <div>
    <div>
      <h2 class="mb-4">Edit Jam Kerja</h2>
      <form method="POST">
        <div class="mb-3">
          <label class="form-label">Kode Shift</label>
          <input type="text" name="kode_shift" class="form-control" value="<?= $row['kode_shift']; ?>" readonly>
        </div>
        <div class="mb-3">
          <label class="form-label">Jam Masuk</label>
          <input type="time" name="jam_masuk" class="form-control" value="<?= $row['jam_masuk']; ?>" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Jam Keluar</label>
          <input type="time" name="jam_keluar" class="form-control" value="<?= $row['jam_keluar']; ?>" required>
        </div>
        <button type="submit" name="update" class="btn btn-warning">Update</button>
        <a href="jam_kerja_list.php" class="btn btn-secondary">Batal</a>
      </form>
    </div>
  </div>
</div>
</body>
</html>
