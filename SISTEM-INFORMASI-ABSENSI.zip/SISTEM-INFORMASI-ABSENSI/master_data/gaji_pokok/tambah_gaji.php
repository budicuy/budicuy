<?php
// master_data/gaji_pokok/tambah_gaji.php
include '../../koneksi.php'; // koneksi DB

// Ambil list karyawan untuk dropdown
$karyawan_q = mysqli_query($conn, "SELECT id_nik, nama FROM karyawan ORDER BY nama ASC");

// Inisialisasi
$errors = [];
$success = null;

// === UPLOAD MASSAL EXCEL ===
if (isset($_POST['upload_excel'])) {
    if (isset($_FILES['file_excel']) && $_FILES['file_excel']['error'] == 0) {
        require_once '../../vendor/autoload.php';
        $ext = strtolower(pathinfo($_FILES['file_excel']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['xls','xlsx'])) {
            $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($_FILES['file_excel']['tmp_name']);
            $sheet = $spreadsheet->getActiveSheet()->toArray();

            $rowCount = 0;
            foreach ($sheet as $i => $row) {
                if ($i == 0) continue; // skip header

                $id_nik     = trim($row[0] ?? '');
                $gaji_input = trim($row[1] ?? '');
                $bulan      = trim($row[2] ?? date('n'));
                $tahun      = trim($row[3] ?? date('Y'));

                if ($id_nik === '' || $gaji_input === '') continue;

                $gaji_clean   = str_replace(['.',','], ['','.',], $gaji_input);
                if (!is_numeric($gaji_clean)) continue;

                $gaji_pokok   = (float)$gaji_clean;
                $upah_per_jam = round($gaji_pokok / 173, 2);

                $sql = "INSERT INTO gaji_pokok (id_nik, gaji_pokok, bulan, tahun) VALUES (?,?,?,?)";
                    $stmt = mysqli_prepare($conn, $sql);
                    mysqli_stmt_bind_param($stmt, "sdii", $id_nik, $gaji_pokok, $bulan, $tahun);

                if (mysqli_stmt_execute($stmt)) {
                    $rowCount++;
                }
            }

            if ($rowCount > 0) {
                echo "<script>alert('Upload massal berhasil, $rowCount baris ditambahkan.'); window.location='gaji_pokok_list.php';</script>";
                exit;
            } else {
                $errors[] = "Tidak ada data valid di file Excel.";
            }
        } else {
            $errors[] = "File harus format .xls atau .xlsx";
        }
    } else {
        $errors[] = "File Excel belum dipilih.";
    }
}

// === FORM MANUAL (asli kamu) ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['upload_excel'])) {
    $id_nik     = $_POST['id_nik'] ?? '';
    $gaji_input = $_POST['gaji_pokok'] ?? '';
    $bulan      = $_POST['bulan'] ?? date('n');
    $tahun      = $_POST['tahun'] ?? date('Y');

    if (!$id_nik) $errors[] = "Pilih karyawan.";
    if ($gaji_input === '') $errors[] = "Isi gaji pokok.";
    $gaji_clean = str_replace(['.',','], ['','.',], $gaji_input);
    if (!is_numeric($gaji_clean)) $errors[] = "Gaji pokok harus berupa angka.";

    if (empty($errors)) {
        $gaji_pokok   = (float)$gaji_clean;
        $upah_per_jam = round($gaji_pokok / 173, 2);

        $colsRes = mysqli_query($conn, "SHOW COLUMNS FROM gaji_pokok");
        $existingCols = [];
        while ($c = mysqli_fetch_assoc($colsRes)) {
            $existingCols[] = $c['Field'];
        }

        $insertCols = [];
        $placeholders = [];
        $values = [];

        if (in_array('id_nik', $existingCols)) { $insertCols[] = 'id_nik'; $placeholders[] = '?'; $values[] = $id_nik; }
        if (in_array('gaji_pokok', $existingCols)) { $insertCols[] = 'gaji_pokok'; $placeholders[] = '?'; $values[] = $gaji_pokok; }
        if (in_array('bulan', $existingCols)) { $insertCols[] = 'bulan'; $placeholders[] = '?'; $values[] = (int)$bulan; }
        if (in_array('tahun', $existingCols)) { $insertCols[] = 'tahun'; $placeholders[] = '?'; $values[] = (int)$tahun; }
        if (in_array('upah_per_jam', $existingCols)) { $insertCols[] = 'upah_per_jam'; $placeholders[] = '?'; $values[] = $upah_per_jam; }

        if (empty($insertCols)) {
            $errors[] = "Kolom yang diperlukan tidak ditemukan di tabel gaji_pokok.";
        } else {
            $sql = "INSERT INTO gaji_pokok (" . implode(',', $insertCols) . ") VALUES (" . implode(',', $placeholders) . ")";
            $stmt = mysqli_prepare($conn, $sql);
            if ($stmt === false) {
                $errors[] = "Prepare statement gagal: " . mysqli_error($conn);
            } else {
                $types = '';
                foreach ($values as $v) {
                    if (is_int($v)) $types .= 'i';
                    elseif (is_float($v) || is_numeric($v) && strpos((string)$v, '.') !== false) $types .= 'd';
                    else $types .= 's';
                }
                mysqli_stmt_bind_param($stmt, $types, ...$values);
                if (mysqli_stmt_execute($stmt)) {
                    echo "<script>alert('Data gaji pokok berhasil ditambahkan.'); window.location='gaji_pokok_list.php';</script>";
                    exit;
                } else {
                    $errors[] = "Gagal menyimpan: " . mysqli_stmt_error($stmt);
                }
            }
        }
    }
}

include '../../sidebar.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <title>Tambah Gaji Pokok</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>.main-content { margin-left:220px; padding:30px; }</style>
</head>
<body>
<div class="main-content">
  <h2 class="mb-4">Tambah Gaji Pokok</h2>

  <?php if (!empty($errors)): ?>
    <div class="alert alert-danger">
      <strong>Terjadi error:</strong>
      <ul><?php foreach($errors as $e) echo "<li>".htmlspecialchars($e)."</li>"; ?></ul>
    </div>
  <?php endif; ?>

  <?php if ($success): ?>
    <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
  <?php endif; ?>

  <!-- FORM UPLOAD MASSAL -->
  <h4>Upload Massal (Excel)</h4>
  <form method="post" enctype="multipart/form-data" class="mb-4">
    <div class="mb-3">
      <input type="file" name="file_excel" accept=".xls,.xlsx" class="form-control" required>
    </div>
    <button type="submit" name="upload_excel" class="btn btn-primary">Upload</button>
  </form>

  <hr>

  <!-- FORM MANUAL -->
  <h4>Input Manual</h4>
  <form method="post">
            <div class="mb-3">
        <label class="form-label">Karyawan (NIK - Nama)</label>
        <select name="id_nik" id="id_nik" class="form-control" required>
            <option value="">-- Pilih Karyawan --</option>
            <?php
            mysqli_data_seek($karyawan_q, 0);
            while ($r = mysqli_fetch_assoc($karyawan_q)) {
                $sel = (isset($id_nik) && $id_nik == $r['id_nik']) ? 'selected' : '';
                echo "<option value='".htmlspecialchars($r['id_nik'])."' $sel>"
                    .htmlspecialchars($r['id_nik']." - ".$r['nama'])
                    ."</option>";
            }
            ?>
        </select>
</div>


    <div class="mb-3">
      <label class="form-label">Gaji Pokok (Rp)</label>
      <input type="text" name="gaji_pokok" class="form-control" value="<?= isset($gaji_input)?htmlspecialchars($gaji_input):'' ?>" required>
    </div>

    <div class="row">
      <div class="col-md-3 mb-3">
        <label class="form-label">Bulan</label>
        <select name="bulan" class="form-control">
          <?php for ($m=1;$m<=12;$m++): 
             $label = date('F', mktime(0,0,0,$m,1));
             $sel = (isset($bulan) && (int)$bulan == $m) ? 'selected' : ((date('n')==$m)?'selected':'');
          ?>
            <option value="<?= $m ?>" <?= $sel ?>><?= $label ?></option>
          <?php endfor; ?>
        </select>
      </div>

      <div class="col-md-3 mb-3">
        <label class="form-label">Tahun</label>
        <select name="tahun" class="form-control">
          <?php 
            $cur = date('Y');
            for ($y=$cur-3; $y <= $cur+1; $y++) {
              $sel = (isset($tahun) && (int)$tahun == $y) ? 'selected' : (($y==$cur)?'selected':'');
              echo "<option value='$y' $sel>$y</option>";
            }
          ?>
        </select>
      </div>

      <div class="col-md-6 mb-3">
        <label class="form-label">Upah per Jam (otomatis)</label>
        <input type="text" id="upah_per_jam" class="form-control" value="<?= isset($gaji_input) ? number_format((float)str_replace(['.',' '],'',$gaji_input)/173,2,'.',',') : '' ?>" readonly>
      </div>
    </div>

    <button type="submit" class="btn btn-success">Simpan</button>
    <a href="gaji_pokok_list.php" class="btn btn-secondary">Batal</a>
  </form>
</div>

<!-- jQuery & Select2 -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script>
  // aktifkan autocomplete untuk dropdown karyawan
  $(document).ready(function() {
    $('#id_nik').select2({
      placeholder: "-- Pilih Karyawan --",
      allowClear: true,
      width: '100%'
    });
  });

  // hitung otomatis upah per jam
  document.querySelector('input[name="gaji_pokok"]').addEventListener('input', function(){
    let v = this.value.replace(/\./g,'').replace(/,/g,'.').replace(/\s/g,'');
    let num = parseFloat(v);
    if (!isNaN(num)) {
      document.getElementById('upah_per_jam').value = (num/173).toFixed(2);
    } else {
      document.getElementById('upah_per_jam').value = '';
    }
  });
</script>

</body>
</html>
