<?php
include '../../koneksi.php';

// Ambil id_gaji dari URL
$id_gaji = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id_gaji <= 0) {
    die("ID gaji tidak valid.");
}

// Ambil data gaji berdasarkan id
$res = mysqli_query($conn, "SELECT * FROM gaji_pokok WHERE id_gaji = $id_gaji");
$data = mysqli_fetch_assoc($res);
if (!$data) {
    die("Data gaji tidak ditemukan.");
}

// Ambil list karyawan
$karyawan_q = mysqli_query($conn, "SELECT id_nik, nama FROM karyawan ORDER BY nama ASC");

// Inisialisasi error & success
$errors = [];
$success = null;

// Proses update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_nik     = $_POST['id_nik'] ?? '';
    $gaji_input = $_POST['gaji_pokok'] ?? '';
    $bulan      = $_POST['bulan'] ?? date('n');
    $tahun      = $_POST['tahun'] ?? date('Y');

    if (!$id_nik) $errors[] = "Pilih karyawan.";
    if ($gaji_input === '') $errors[] = "Isi gaji pokok.";

    // ✅ Perbaikan sanitasi input agar tidak berubah jadi miliaran
    $gaji_clean = preg_replace('/[^0-9]/', '', $gaji_input);
    if ($gaji_clean === '' || !is_numeric($gaji_clean)) {
        $errors[] = "Gaji pokok harus angka.";
    }

    if (empty($errors)) {
        $gaji_pokok   = (float)$gaji_clean;
        $upah_per_jam = round($gaji_pokok / 173, 2);

        // Cek kolom yang ada
        $colsRes = mysqli_query($conn, "SHOW COLUMNS FROM gaji_pokok");
        $existingCols = [];
        while ($c = mysqli_fetch_assoc($colsRes)) {
            $existingCols[] = $c['Field'];
        }

        // Bangun query update
        $updates = [];
        $values = [];
        $types  = '';

        if (in_array('id_nik', $existingCols)) { $updates[] = 'id_nik=?'; $values[] = $id_nik; $types .= 's'; }
        if (in_array('gaji_pokok', $existingCols)) { $updates[] = 'gaji_pokok=?'; $values[] = $gaji_pokok; $types .= 'd'; }
        if (in_array('bulan', $existingCols)) { $updates[] = 'bulan=?'; $values[] = (int)$bulan; $types .= 'i'; }
        if (in_array('tahun', $existingCols)) { $updates[] = 'tahun=?'; $values[] = (int)$tahun; $types .= 'i'; }
        if (in_array('upah_per_jam', $existingCols)) { $updates[] = 'upah_per_jam=?'; $values[] = $upah_per_jam; $types .= 'd'; }

        if (!empty($updates)) {
            $sql = "UPDATE gaji_pokok SET " . implode(',', $updates) . " WHERE id_gaji=?";
            $values[] = $id_gaji;
            $types .= 'i';

            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, $types, ...$values);

            if (mysqli_stmt_execute($stmt)) {
                echo "<script>alert('Data gaji berhasil diperbarui'); window.location='gaji_pokok_list.php';</script>";
                exit;
            } else {
                $errors[] = "Gagal update: " . mysqli_stmt_error($stmt);
            }
        } else {
            $errors[] = "Tidak ada kolom yang bisa diupdate.";
        }
    }
}

include '../../sidebar.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <title>Edit Gaji Pokok</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .main-content { margin-left:220px; padding:30px; }
  </style>
</head>
<body>
<div class="main-content">
  <h2 class="mb-4">Edit Gaji Pokok</h2>

  <?php if (!empty($errors)): ?>
    <div class="alert alert-danger">
      <ul><?php foreach($errors as $e) echo "<li>".htmlspecialchars($e)."</li>"; ?></ul>
    </div>
  <?php endif; ?>

  <form method="post">
    <div class="mb-3">
      <label class="form-label">Karyawan</label>
      <select name="id_nik" class="form-control" required>
        <option value="">-- Pilih Karyawan --</option>
        <?php while ($r = mysqli_fetch_assoc($karyawan_q)) { 
          $sel = ($r['id_nik'] == $data['id_nik']) ? 'selected' : '';
          echo "<option value='".htmlspecialchars($r['id_nik'])."' $sel>".htmlspecialchars($r['id_nik']." - ".$r['nama'])."</option>";
        } ?>
      </select>
    </div>

    <div class="mb-3">
      <label class="form-label">Gaji Pokok (Rp)</label>
      <input type="text" name="gaji_pokok" class="form-control" 
             value="<?= number_format($data['gaji_pokok'],0,',','.') ?>" required>
    </div>

    <div class="row">
      <div class="col-md-3 mb-3">
        <label class="form-label">Bulan</label>
        <select name="bulan" class="form-control">
          <?php for ($m=1;$m<=12;$m++): 
            $label = date('F', mktime(0,0,0,$m,1));
            $sel = ($data['bulan'] == $m) ? 'selected' : '';
          ?>
            <option value="<?= $m ?>" <?= $sel ?>><?= $label ?></option>
          <?php endfor; ?>
        </select>
      </div>

      <div class="col-md-3 mb-3">
        <label class="form-label">Tahun</label>
        <select name="tahun" class="form-control">
          <?php 
            $cur = date('Y');
            for ($y=$cur-3; $y <= $cur+1; $y++) {
              $sel = ($data['tahun'] == $y) ? 'selected' : '';
              echo "<option value='$y' $sel>$y</option>";
            }
          ?>
        </select>
      </div>

      <div class="col-md-6 mb-3">
        <label class="form-label">Upah per Jam</label>
        <input type="text" id="upah_per_jam" class="form-control" 
               value="<?= number_format($data['gaji_pokok']/173,2,',','.') ?>" readonly>
      </div>
    </div>

    <button type="submit" class="btn btn-primary">Update</button>
    <a href="gaji_pokok_list.php" class="btn btn-secondary">Batal</a>
  </form>
</div>

<script>
  document.querySelector('input[name="gaji_pokok"]').addEventListener('input', function(){
    let v = this.value.replace(/\./g,'').replace(/,/g,'').replace(/\s/g,'');
    let num = parseFloat(v);
    if (!isNaN(num)) {
      document.getElementById('upah_per_jam').value = (num/173).toFixed(2);
    } else {
      document.getElementById('upah_per_jam').value = '';
    }
  });
</script>
</body>
</html>
