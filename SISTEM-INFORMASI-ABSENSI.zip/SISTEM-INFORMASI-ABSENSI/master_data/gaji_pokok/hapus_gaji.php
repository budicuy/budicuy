<?php
include '../../koneksi.php';

// Jika hapus multiple via POST (dari checkbox)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['ids'])) {
    $ids = $_POST['ids'];
    $ids = array_map('intval', $ids); // sanitasi angka
    $idList = implode(',', $ids);

    if (!empty($idList)) {
        $q = "DELETE FROM gaji_pokok WHERE id_gaji IN ($idList)";
        if (mysqli_query($conn, $q)) {
            echo "<script>alert('Data gaji berhasil dihapus'); window.location='gaji_pokok_list.php';</script>";
            exit;
        } else {
            echo "<script>alert('Gagal menghapus data: ".mysqli_error($conn)."'); window.location='gaji_pokok_list.php';</script>";
            exit;
        }
    }
}

// Jika hapus 1 data via GET
if (isset($_GET['id'])) {
    $id = (int) $_GET['id'];
    if ($id > 0) {
        $q = "DELETE FROM gaji_pokok WHERE id_gaji = $id";
        if (mysqli_query($conn, $q)) {
            echo "<script>alert('Data gaji berhasil dihapus'); window.location='gaji_pokok_list.php';</script>";
            exit;
        } else {
            echo "<script>alert('Gagal menghapus data: ".mysqli_error($conn)."'); window.location='gaji_pokok_list.php';</script>";
            exit;
        }
    }
}

// Jika tidak ada parameter
echo "<script>alert('Tidak ada data yang dipilih untuk dihapus'); window.location='gaji_pokok_list.php';</script>";
exit;
