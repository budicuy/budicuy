<?php
include '../../koneksi.php';
include '../../sidebar.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Master Gaji Pokok</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.5/css/dataTables.bootstrap5.min.css">
  <style>
    .main-content { margin-left:220px; padding:30px; }
  </style>
</head>
<body>
<div class="main-content">
  <div>
    <div>
      <h2 class="mb-4">MASTER GAJI POKOK</h2>
      <a href="tambah_gaji.php" class="btn btn-success mb-3">+ Tambah Gaji Pokok</a>
      <div class="table-responsive">
        <table id="tabelGaji" class="table table-striped table-bordered align-middle">
          <thead class="table-dark text-center">
            <tr>
              <th>No</th>
              <th>NIK</th>
              <th>Nama</th>
              <th>Departemen</th>
              <th>Vendor</th>
              <th>Gaji Pokok</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $sql = "SELECT g.id_gaji, k.id_nik, k.nama, d.nama_departemen, v.nama_vendor, g.gaji_pokok 
                    FROM gaji_pokok g
                    JOIN karyawan k ON g.id_nik = k.id_nik
                    LEFT JOIN departemen d ON k.id_dept = d.id_dept
                    LEFT JOIN vendor v ON k.id_vendor = v.id_vendor";
            $result = mysqli_query($conn, $sql);
            $no=1;
            while ($row=mysqli_fetch_assoc($result)) {
              echo "<tr>
                      <td>".$no++."</td>
                      <td>".$row['id_nik']."</td>
                      <td>".$row['nama']."</td>
                      <td>".$row['nama_departemen']."</td>
                      <td>".$row['nama_vendor']."</td>
                      <td>Rp ".number_format($row['gaji_pokok'],0,',','.')."</td>
                      <td class='text-center'>
                        <a href='edit_gaji.php?id=".$row['id_gaji']."' class='btn btn-warning btn-sm'>Edit</a>
                        <a href='hapus_gaji.php?id=".$row['id_gaji']."' onclick=\"return confirm('Yakin?')\" class='btn btn-danger btn-sm'>Hapus</a>
                      </td>
                    </tr>";
            }
            ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.5/js/dataTables.bootstrap5.min.js"></script>
<script>
$(document).ready(function(){
  var t = $('#tabelGaji').DataTable({
    "columnDefs": [{
      "searchable": false,
      "orderable": false,
      "targets": 0
    }],
    "order": [[1, 'asc']],
    "pageLength": 50   // <- set default show entries jadi 50
    
  });

  // override nomor biar tetap urut setelah sort/filter
  t.on('order.dt search.dt', function(){
    t.column(0, {search:'applied', order:'applied'}).nodes().each(function(cell, i){
      cell.innerHTML = i+1;
    });
  }).draw();
});
</script>
</body>
</html>
