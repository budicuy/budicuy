<?php
include '../../koneksi.php';
require '../../vendor/autoload.php'; // pastikan phpoffice/phpspreadsheet sudah terinstal
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Shared\Date;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // ===== Upload Massal Excel =====
    if (isset($_FILES['file_excel']) && $_FILES['file_excel']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['file_excel']['tmp_name'];
        $spreadsheet = IOFactory::load($fileTmpPath);
        $sheet = $spreadsheet->getActiveSheet()->toArray();

        $rowNo = 0;
        $errors = [];
        foreach ($sheet as $row) {
            $rowNo++;
            if ($rowNo == 1) continue; // skip header

            // mapping kolom excel
            $id_nik      = trim($row[0] ?? '');
            $nama        = trim($row[1] ?? '');
            $nama_dept   = trim($row[2] ?? '');
            $nama_vendor = trim($row[3] ?? '');
            $no_hp       = trim($row[4] ?? '');
            $tmkRaw      = trim($row[5] ?? '');
            $alamat      = trim($row[6] ?? '');

            // === Normalisasi nomor HP ===
            if (!empty($no_hp)) {
                $no_hp = (string)$no_hp;
                if (preg_match('/^8[0-9]+$/', $no_hp)) {
                    $no_hp = '0' . $no_hp;
                }
                if (preg_match('/^0[0-9]+$/', $no_hp)) {
                    $no_hp = '+62' . substr($no_hp, 1);
                }
            }

            // Konversi tanggal TMK
            $tmk = null;
            if (!empty($tmkRaw)) {
                if (is_numeric($tmkRaw)) {
                    $tmk = date('Y-m-d', Date::excelToTimestamp($tmkRaw));
                } else {
                    $timestamp = strtotime(str_replace('-', '/', $tmkRaw));
                    $tmk = $timestamp ? date('Y-m-d', $timestamp) : null;
                }
            }

            // Cek NIK sudah ada
            $cekNik = mysqli_query($conn, "SELECT 1 FROM karyawan WHERE id_nik='" . mysqli_real_escape_string($conn, $id_nik) . "'");
            if (mysqli_num_rows($cekNik) > 0) {
                $errors[] = "Baris $rowNo: NIK $id_nik sudah terdaftar.";
                continue;
            }

            // Cari id_dept dari nama departemen
            $deptQuery = mysqli_query($conn, "SELECT id_dept FROM departemen WHERE nama_departemen='" . mysqli_real_escape_string($conn, $nama_dept) . "'");
            if ($d = mysqli_fetch_assoc($deptQuery)) {
                $id_dept_db = (int)$d['id_dept'];
            } else {
                $errors[] = "Baris $rowNo: Departemen '$nama_dept' tidak ditemukan.";
                continue;
            }

            // Cari id_vendor dari nama vendor (boleh kosong)
            if ($nama_vendor) {
                $vendorQuery = mysqli_query($conn, "SELECT id_vendor FROM vendor WHERE nama_vendor='" . mysqli_real_escape_string($conn, $nama_vendor) . "'");
                if ($v = mysqli_fetch_assoc($vendorQuery)) {
                    $id_vendor_db = (int)$v['id_vendor'];
                } else {
                    $errors[] = "Baris $rowNo: Vendor '$nama_vendor' tidak ditemukan.";
                    continue;
                }
            } else {
                $id_vendor_db = null;
            }

            // Insert ke database
            $sql = "INSERT INTO karyawan (id_nik, nama, id_dept, id_vendor, no_hp, tmk, alamat)
                    VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param(
                $stmt,
                "ssissss",
                $id_nik,
                $nama,
                $id_dept_db,
                $id_vendor_db,
                $no_hp,
                $tmk,
                $alamat
            );
            if (!mysqli_stmt_execute($stmt)) {
                $errors[] = "Baris $rowNo: Gagal insert. " . mysqli_stmt_error($stmt);
            }
        }

        if (!empty($errors)) {
            echo "<div class='alert alert-danger'><strong>Error Upload:</strong><br>" . implode('<br>', $errors) . "</div>";
        } else {
            echo "<script>alert('Upload massal karyawan berhasil!'); window.location='karyawan_list.php';</script>";
            exit;
        }
    }

    // ===== Input Manual =====
    else if (isset($_POST['simpan'])) {
        $id_nik     = $_POST['id_nik'];
        $nama       = $_POST['nama'];
        $id_dept    = $_POST['id_dept'];
        $id_vendor  = $_POST['id_vendor'] ?: NULL;
        $no_hp      = trim($_POST['no_hp']);
        $tmk        = $_POST['tmk'];
        $alamat     = $_POST['alamat'];

        // === Normalisasi nomor HP ===
        if (!empty($no_hp)) {
            if (preg_match('/^8[0-9]+$/', $no_hp)) {
                $no_hp = '0' . $no_hp;
            }
            if (preg_match('/^0[0-9]+$/', $no_hp)) {
                $no_hp = '+62' . substr($no_hp, 1);
            }
        }

        $sql = "INSERT INTO karyawan (id_nik, nama, id_dept, id_vendor, no_hp, tmk, alamat) 
                VALUES ('$id_nik', '$nama', '$id_dept', " . ($id_vendor ? "'$id_vendor'" : "NULL") . ", '$no_hp', '$tmk', '$alamat')";

        if (mysqli_query($conn, $sql)) {
            header("Location: karyawan_list.php");
            exit;
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    }
}

// Ambil daftar departemen
$departemen = mysqli_query($conn, "SELECT * FROM departemen ORDER BY nama_departemen ASC");

// Ambil daftar vendor
$vendor = mysqli_query($conn, "SELECT * FROM vendor ORDER BY nama_vendor ASC");
?>

<?php include '../../sidebar.php'; ?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Tambah Karyawan</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
  <style>
    .main-content { margin-left: 220px; padding: 30px; }
    .select2-container--default .select2-selection--single { height: 38px; }
  </style>
</head>
<body>
<div class="main-content">
  <h2 class="mb-4">Tambah Karyawan</h2>

  <!-- Form Upload Excel -->
  <form method="POST" enctype="multipart/form-data" class="mb-4">
    <div class="mb-3">
      <label class="form-label">Upload Excel (NIK, Nama, Departemen, Vendor, No HP, TMK d-m-Y, Alamat)</label>
      <input type="file" name="file_excel" class="form-control" accept=".xlsx,.xls">
    </div>
    <button type="submit" class="btn btn-primary">Upload Massal</button>
  </form>

  <hr>

  <!-- Form Manual -->
  <form method="post">
    <div class="mb-3">
      <label>NIK</label>
      <input type="text" name="id_nik" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Nama</label>
      <input type="text" name="nama" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Departemen</label>
      <select name="id_dept" id="id_dept" class="form-control" required>
        <option value="">-- Pilih Departemen --</option>
        <?php while($row = mysqli_fetch_assoc($departemen)) { ?>
          <option value="<?= $row['id_dept']; ?>"><?= $row['nama_departemen']; ?></option>
        <?php } ?>
      </select>
    </div>
    <div class="mb-3">
      <label>Vendor</label>
      <select name="id_vendor" id="id_vendor" class="form-control">
        <option value="">-- Pilih Vendor --</option>
        <?php 
        mysqli_data_seek($vendor, 0); // reset pointer
        while($v = mysqli_fetch_assoc($vendor)) { ?>
          <option value="<?= $v['id_vendor']; ?>"><?= $v['nama_vendor']; ?></option>
        <?php } ?>
      </select>
    </div>
    <div class="mb-3">
      <label>No HP</label>
      <input type="text" name="no_hp" class="form-control">
    </div>
    <div class="mb-3">
      <label>TMK</label>
      <input type="date" name="tmk" class="form-control">
    </div>
    <div class="mb-3">
      <label>Alamat</label>
      <textarea name="alamat" class="form-control"></textarea>
    </div>
    <button type="submit" name="simpan" class="btn btn-success">Simpan</button>
    <a href="karyawan_list.php" class="btn btn-secondary">Batal</a>
  </form>
</div>

<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
$(document).ready(function(){
    $('#id_dept').select2({placeholder: "-- Pilih Departemen --", allowClear:true, width:'100%'});
    $('#id_vendor').select2({placeholder: "-- Pilih Vendor --", allowClear:true, width:'100%'});
});
</script>
</body>
</html>
