<?php
include '../../koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['selected'])) {
    $ids = $_POST['selected'];

    // Escape biar aman
    $ids_escaped = array_map(function($id) use ($conn) {
        return "'" . mysqli_real_escape_string($conn, $id) . "'";
    }, $ids);

    $ids_sql = implode(",", $ids_escaped);
    $sql = "DELETE FROM karyawan WHERE id_nik IN ($ids_sql)";

    if (mysqli_query($conn, $sql)) {
        header("Location: karyawan_list.php");
        exit;
    } else {
        echo "Error: " . mysqli_error($conn);
    }
} else {
    header("Location: karyawan_list.php");
    exit;
}
?>
