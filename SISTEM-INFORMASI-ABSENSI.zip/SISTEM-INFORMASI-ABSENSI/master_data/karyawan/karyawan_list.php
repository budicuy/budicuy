<?php
include '../../koneksi.php';
include '../../sidebar.php';

// Ambil filter dari GET
$filter_dept   = $_GET['dept'] ?? '';
$filter_vendor = $_GET['vendor'] ?? '';

// Query dasar
$where = [];
if ($filter_dept)   $where[] = "k.id_dept = '".mysqli_real_escape_string($conn, $filter_dept)."'";
if ($filter_vendor) $where[] = "k.id_vendor = '".mysqli_real_escape_string($conn, $filter_vendor)."'";

$whereSql = $where ? "WHERE ".implode(" AND ", $where) : "";

$sql = "SELECT 
          k.id_nik, k.nama, d.nama_departemen, v.nama_vendor, 
          k.no_hp, k.tmk, k.alamat
        FROM karyawan k
        LEFT JOIN departemen d ON k.id_dept = d.id_dept
        LEFT JOIN vendor v ON k.id_vendor = v.id_vendor
        $whereSql
        ORDER BY k.nama ASC";
$result = mysqli_query($conn, $sql);

// Ambil list departemen & vendor untuk dropdown
$departemen = mysqli_query($conn, "SELECT * FROM departemen ORDER BY nama_departemen ASC");
$vendor     = mysqli_query($conn, "SELECT * FROM vendor ORDER BY nama_vendor ASC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Data Karyawan</title>
  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- DataTables CSS -->
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.5/css/dataTables.bootstrap5.min.css">
  <style>
    body { background-color: #f8f9fa; }
    .main-content { margin-left: 220px; padding: 30px; }
  </style>
</head>
<body>

<div class="main-content">
  <h2 class="mb-4">DATA KARYAWAN</h2>

  <!-- Tombol Tambah -->
  <a href="tambah_karyawan.php" class="btn btn-success mb-3">+ Tambah Karyawan</a>

  <!-- Filter -->
  <form method="get" class="row g-2 mb-4">
    <div class="col-md-4">
      <select name="dept" class="form-control">
        <option value="">-- Semua Departemen --</option>
        <?php while($d = mysqli_fetch_assoc($departemen)) { ?>
          <option value="<?= $d['id_dept']; ?>" <?= ($filter_dept==$d['id_dept'])?'selected':''; ?>>
            <?= htmlspecialchars($d['nama_departemen']); ?>
          </option>
        <?php } ?>
      </select>
    </div>
    <div class="col-md-4">
      <select name="vendor" class="form-control">
        <option value="">-- Semua Vendor --</option>
        <?php while($v = mysqli_fetch_assoc($vendor)) { ?>
          <option value="<?= $v['id_vendor']; ?>" <?= ($filter_vendor==$v['id_vendor'])?'selected':''; ?>>
            <?= htmlspecialchars($v['nama_vendor']); ?>
          </option>
        <?php } ?>
      </select>
    </div>
    <div class="col-md-4 d-flex gap-2">
      <button class="btn btn-primary">Filter</button>
      <a href="karyawan_list.php" class="btn btn-secondary">Reset</a>
    </div>
  </form>

  <!-- Form Hapus Massal -->
  <form id="formBulk" method="post" action="hapus_karyawan.php">
    <button type="submit" class="btn btn-danger mb-3" onclick="return confirm('Yakin ingin menghapus data terpilih?');">Hapus Terpilih</button>

    <div class="table-responsive">
      <table id="tabelKaryawan" class="table table-striped table-bordered align-middle">
        <thead class="table-dark text-center">
          <tr>
            <th><input type="checkbox" id="checkAll"></th>
            <th style="width:50px;">No</th>
            <th>NIK</th>
            <th>Nama</th>
            <th>Departemen</th>
            <th>Vendor</th>
            <th>No HP</th>
            <th>TMK</th>
            <th>Alamat</th>
            <th style="width:180px;">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php
          if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
              echo "<tr>";
              echo "<td class='text-center'><input type='checkbox' name='selected[]' value='".$row['id_nik']."'></td>";
              echo "<td></td>"; // auto numbering oleh DataTables
              echo "<td>".htmlspecialchars((string)$row['id_nik'])."</td>";
              echo "<td>".htmlspecialchars((string)$row['nama'])."</td>";
              echo "<td>".htmlspecialchars((string)$row['nama_departemen'])."</td>";
              echo "<td>".htmlspecialchars((string)$row['nama_vendor'])."</td>";
              echo "<td>".htmlspecialchars((string)$row['no_hp'])."</td>";
              echo "<td>".htmlspecialchars((string)$row['tmk'])."</td>";
              echo "<td>".htmlspecialchars((string)$row['alamat'])."</td>";
              echo "<td class='text-center'>
                      <a href='edit_karyawan.php?id=".$row['id_nik']."' class='btn btn-warning btn-sm'>Edit</a>
                      <a href='hapus_karyawan.php?id=".$row['id_nik']."' class='btn btn-danger btn-sm' onclick=\"return confirm('Yakin ingin menghapus data ini?');\">Hapus</a>
                    </td>";
              echo "</tr>";
            }
          }
          ?>
        </tbody>
      </table>
    </div>
  </form>
</div>

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- DataTables JS -->
<script src="https://cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.5/js/dataTables.bootstrap5.min.js"></script>

<script>
$(document).ready(function () {
var t = $('#tabelKaryawan').DataTable({
  columnDefs: [
    { targets: [0,1], orderable: false, searchable: false },
    { targets: -1, orderable: false }
  ],
  order: [[2, 'asc']],
  pageLength: 50   // 👈 default tampilkan 50 data
});


  // Auto numbering kolom No
  t.on('order.dt search.dt', function(){
      let i = 1;
      t.cells(null, 1, { search: 'applied', order: 'applied' }).every(function(){
          this.data(i++);
      });
  }).draw();

  // Checkbox Select All
  $('#checkAll').on('click', function(){
    $('input[name="selected[]"]').prop('checked', this.checked);
  });
});
</script>

</body>
</html>
