<?php
include '../../koneksi.php';

$id = $_GET['id'];

// Ambil data karyawan
$sql = "SELECT * FROM karyawan WHERE id_nik='$id'";
$result = mysqli_query($conn, $sql);
$data = mysqli_fetch_assoc($result);

// Ambil daftar departemen
$departemen = mysqli_query($conn, "SELECT * FROM departemen ORDER BY nama_departemen ASC");

// Ambil daftar vendor
$vendor = mysqli_query($conn, "SELECT * FROM vendor ORDER BY nama_vendor ASC");

if (isset($_POST['update'])) {
    $nama      = $_POST['nama'];
    $id_dept   = $_POST['id_dept'];
    $id_vendor = $_POST['id_vendor'] ?: NULL; // jika kosong, simpan NULL
    $no_hp     = $_POST['no_hp'];
    $tmk       = $_POST['tmk'];
    $alamat    = $_POST['alamat'];

    $update = "UPDATE karyawan 
               SET nama='$nama', id_dept='$id_dept', id_vendor=".($id_vendor ? "'$id_vendor'" : "NULL").",
                   no_hp='$no_hp', tmk='$tmk', alamat='$alamat' 
               WHERE id_nik='$id'";

    if (mysqli_query($conn, $update)) {
        header("Location: karyawan_list.php");
        exit;
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}

include '../../sidebar.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Edit Karyawan</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .main-content { margin-left: 220px; padding: 30px; }
  </style>
</head>
<body>
<div class="main-content">
  <div>
    <div>
      <h2 class="mb-4">Edit Karyawan</h2>
      <form method="post">
        <div class="mb-3">
          <label>NIK</label>
          <input type="text" name="id_nik" value="<?= $data['id_nik'] ?>" class="form-control bg-light" readonly>
        </div>

        <div class="mb-3">
          <label>Nama</label>
          <input type="text" name="nama" value="<?= $data['nama'] ?>" class="form-control" required>
        </div>

        <div class="mb-3">
          <label>Departemen</label>
          <select name="id_dept" class="form-control" required>
            <option value="">-- Pilih Departemen --</option>
            <?php while($row = mysqli_fetch_assoc($departemen)) { ?>
              <option value="<?= $row['id_dept']; ?>" 
                <?= ($row['id_dept'] == $data['id_dept']) ? 'selected' : ''; ?>>
                <?= $row['nama_departemen']; ?>
              </option>
            <?php } ?>
          </select>
        </div>

        <div class="mb-3">
          <label>Vendor</label>
          <select name="id_vendor" class="form-control">
            <option value="">-- Pilih Vendor --</option>
            <?php 
            mysqli_data_seek($vendor, 0); // reset pointer
            while($v = mysqli_fetch_assoc($vendor)) { ?>
              <option value="<?= $v['id_vendor']; ?>" 
                <?= ($v['id_vendor'] == $data['id_vendor']) ? 'selected' : ''; ?>>
                <?= $v['nama_vendor']; ?>
              </option>
            <?php } ?>
          </select>
        </div>

        <div class="mb-3">
          <label>No HP</label>
          <input type="text" name="no_hp" value="<?= $data['no_hp'] ?>" class="form-control">
        </div>

        <div class="mb-3">
          <label>TMK</label>
          <input type="date" name="tmk" value="<?= $data['tmk'] ?>" class="form-control">
        </div>

        <div class="mb-3">
          <label>Alamat</label>
          <textarea name="alamat" class="form-control"><?= $data['alamat'] ?></textarea>
        </div>

        <button type="submit" name="update" class="btn btn-warning">Update</button>
        <a href="karyawan_list.php" class="btn btn-secondary">Batal</a>
      </form>
    </div>
  </div>
</div>
</body>
</html>
