<?php
include '../../koneksi.php';

if (isset($_POST['simpan'])) {
    $nik      = $_POST['nik'];
    $nama     = $_POST['nama'];
    $id_dept  = $_POST['id_dept']; // pakai id_dept, bukan teks departemen
    $level    = $_POST['level'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $sql = "INSERT INTO user (nik, nama, id_dept, level, password) 
            VALUES ('$nik', '$nama', '$id_dept', '$level', '$password')";
    if (mysqli_query($conn, $sql)) {
        header("Location: user_list.php");
        exit;
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}

include '../../sidebar.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Tambah User</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    .main-content {
      margin-left: 220px; 
      padding: 30px;
    }

  </style>
</head>
<body>
<div class="main-content">
  <div>
    <div>
      <h2 class="mb-4">Tambah User</h2>
      <form method="post">
        <!-- Dropdown Pilih NIK -->
        <div class="mb-3">
          <label>Pilih Karyawan (Cari)</label>
          <select name="nik" id="nik" class="form-control" required>
            <option value="">-- Pilih Karyawan --</option>
            <?php
              $qry = mysqli_query($conn, "
                SELECT k.id_nik, k.nama, d.id_dept, d.nama_departemen
                FROM karyawan k
                LEFT JOIN departemen d ON k.id_dept = d.id_dept
                ORDER BY k.id_nik ASC
              ");
              while ($row = mysqli_fetch_assoc($qry)) {
                  echo "<option value='".$row['id_nik']."' 
                          data-nama='".$row['nama']."' 
                          data-iddept='".$row['id_dept']."' 
                          data-namadept='".$row['nama_departemen']."'>
                          ".$row['id_nik']." - ".$row['nama']." (".$row['nama_departemen'].")
                        </option>";
              }
            ?>
          </select>
        </div>

        <!-- Nama otomatis terisi -->
        <div class="mb-3">
          <label>Nama</label>
          <input type="text" name="nama" id="nama" class="form-control" readonly required>
        </div>

        <!-- Departemen otomatis terisi (hidden id_dept + tampil nama dept) -->
        <div class="mb-3">
          <label>Departemen</label>
          <input type="hidden" name="id_dept" id="id_dept">
          <input type="text" id="nama_departemen" class="form-control" readonly>
        </div>

        <!-- Pilih Level -->
        <div class="mb-3">
          <label>Level</label>
          <select name="level" class="form-control" required>
            <option value="Super Admin">Super Admin</option>  
            <option value="Admin">Admin</option>
            <option value="User">User</option>
          </select>
        </div>

        <!-- Password -->
        <div class="mb-3">
          <label>Password</label>
          <div class="input-group">
              <input type="password" name="password" id="password" class="form-control" required>
              <button type="button" class="btn btn-outline-secondary" id="togglePassword">
                <i class="bi bi-eye"></i>
              </button>
          </div>
        </div>

        <button type="submit" name="simpan" class="btn btn-success">Simpan</button>
        <a href="user_list.php" class="btn btn-secondary">Batal</a>
      </form>
    </div>
  </div>
</div>

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- Select2 JS -->
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script>
$(document).ready(function() {
  // aktifkan select2
  $('#nik').select2({
    placeholder: "-- Pilih Karyawan --",
    allowClear: true
  });

  // jika pilih NIK, otomatis isi Nama & Departemen
  $('#nik').on('change', function() {
    let nama = $(this).find(':selected').data('nama');
    let id_dept = $(this).find(':selected').data('iddept');
    let nama_departemen = $(this).find(':selected').data('namadept');

    $('#nama').val(nama);
    $('#id_dept').val(id_dept);
    $('#nama_departemen').val(nama_departemen);
  });
});

// Toggle password visibility
$('#togglePassword').on('click', function () {
  const passwordField = $('#password');
  const type = passwordField.attr('type') === 'password' ? 'text' : 'password';
  passwordField.attr('type', type);

  // ganti ikon
  $(this).find('i').toggleClass('bi-eye bi-eye-slash');
});
</script>
</body>
</html>
