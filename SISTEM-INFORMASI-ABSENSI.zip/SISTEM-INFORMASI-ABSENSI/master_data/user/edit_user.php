<?php
include '../../koneksi.php';


// Ambil NIK dari parameter URL
$nik = $_GET['nik'];

// Ambil data user berdasarkan nik
$sql = "SELECT * FROM user WHERE nik='$nik'";
$result = mysqli_query($conn, $sql);
$data = mysqli_fetch_assoc($result);

if (isset($_POST['update'])) {
    $nama     = $_POST['nama'];
    $level    = $_POST['level'];

    // kalau password diisi, update dengan hash baru
    if (!empty($_POST['password'])) {
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $update = "UPDATE user 
                   SET nama='$nama', password='$password', level='$level' 
                   WHERE nik='$nik'";
    } else {
        $update = "UPDATE user 
                   SET nama='$nama', level='$level' 
                   WHERE nik='$nik'";
    }

    if (mysqli_query($conn, $update)) {
        header("Location: user_list.php");
        exit;
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
include '../../sidebar.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Edit User</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .main-content {
      margin-left: 220px; /* sesuai lebar sidebar */
      padding: 30px;
    }
    .card {
      border: none;
      border-radius: 15px;
      box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }
  </style>
</head>
<body>
<div class="main-content">
  <div class="card">
    <div class="card-body">
      <h2 class="mb-4">Edit User</h2>
      <form method="post">
        <div class="mb-3">
          <label>NIK</label>
          <input type="text" 
                 name="nik" 
                 value="<?= $data['nik'] ?>" 
                 class="form-control bg-light" 
                 readonly>
        </div>
        <div class="mb-3">
          <label>Nama</label>
          <input type="text" name="nama" value="<?= $data['nama'] ?>" class="form-control" required>
        </div>
        <div class="mb-3">
          <label>Password (Kosongkan jika tidak ingin diubah)</label>
          <div class="input-group">
            <input type="password" name="password" id="password" class="form-control">
            <button type="button" class="btn btn-outline-secondary" onclick="togglePassword()">
              👁
            </button>
          </div>
        </div>
            <div class="mb-3">
            <label>Level</label>
            <select name="level" class="form-control" required>
                <option value="super_admin" <?= $data['level']=='super_admin'?'selected':'' ?>>Super Admin</option>
                <option value="admin" <?= $data['level']=='admin'?'selected':'' ?>>Admin</option>
                <option value="user" <?= $data['level']=='user'?'selected':'' ?>>User</option>
            </select>
            </div>
        <button type="submit" name="update" class="btn btn-warning">Update</button>
        <a href="user_list.php" class="btn btn-secondary">Batal</a>
      </form>
    </div>
  </div>
</div>

<script>
function togglePassword() {
    const pass = document.getElementById("password");
    pass.type = pass.type === "password" ? "text" : "password";
}
</script>
</body>
</html>
