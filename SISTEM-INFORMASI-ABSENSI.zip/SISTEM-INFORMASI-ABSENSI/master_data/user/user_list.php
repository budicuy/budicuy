<?php
include '../../koneksi.php';
include '../../sidebar.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Data User</title>
  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- DataTables CSS -->
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.5/css/dataTables.bootstrap5.min.css">
  <style>
    body {
      background-color: #f8f9fa;
    }
    .main-content {
      margin-left: 220px; /* lebar sidebar */
      padding: 30px;
    }

    
  </style>
</head>
<body>

<div class="main-content">
  <div>
    <div>
      <h2 class="mb-4">DATA USER</h2>

      <!-- Tombol Tambah -->
      <a href="tambah_user.php" class="btn btn-success mb-3">+ Tambah User</a>

      <div class="table-responsive">
        <table id="tabelUser" class="table table-striped table-bordered align-middle">
          <thead class="table-dark">
            <tr>
              <th>No</th>
              <th>NIK</th>
              <th>Nama</th>
              <th>Departemen</th>
              <th>Level</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $sql = "SELECT u.nik, u.nama, d.nama_departemen, u.level 
            FROM user u
            LEFT JOIN departemen d ON u.id_dept = d.id_dept";

            $result = mysqli_query($conn, $sql);
            $no = 1;
            if (mysqli_num_rows($result) > 0) {
              while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>".$no++."</td>";
                echo "<td>".$row['nik']."</td>";
                echo "<td>".$row['nama']."</td>";
                echo "<td>".$row['nama_departemen']."</td>";
                echo "<td>".ucwords(str_replace("_", " ", $row['level']))."</td>";
                echo "<td>
                        <a href='edit_user.php?nik=".$row['nik']."' class='btn btn-warning btn-sm'>Edit</a>
                        <a href='hapus_user.php?nik=".$row['nik']."' class='btn btn-danger btn-sm' onclick=\"return confirm('Yakin ingin menghapus user ini?');\">Hapus</a>
                      </td>";
                echo "</tr>";
              }
            }
            ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- DataTables JS -->
<script src="https://cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.5/js/dataTables.bootstrap5.min.js"></script>

<script>
$(document).ready(function () {
  $('#tabelUser').DataTable();
});
</script>

</body>
</html>
