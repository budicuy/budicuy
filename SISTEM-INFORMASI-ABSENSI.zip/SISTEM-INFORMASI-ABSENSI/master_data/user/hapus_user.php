<?php
include '../../koneksi.php';

if (isset($_GET['nik'])) {
    $nik = $_GET['nik'];
    mysqli_query($conn, "DELETE FROM user WHERE nik='$nik'");
}
header("Location: user_list.php?msg=deleted");
exit;
