<?php
include '../../koneksi.php';
include '../../sidebar.php';

// Ambil data reason
$reason = mysqli_query($conn, "SELECT * FROM reason ORDER BY nama_reason ASC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Data Reason Lembur</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" rel="stylesheet">
  <style>
    .main-content { margin-left: 220px; padding: 30px; }
  </style>
</head>
<body>
<div class="main-content">
  <div>
    <div>
      <h2 class="mb-4">DATA ALASAN LEMBUR</h2>
      <a href="tambah_reason.php" class="btn btn-success mb-3">+ Tambah Reason</a>

      <div class="table-responsive">
        <table id="reasonTable" class="table table-bordered table-striped align-middle">
          <thead class="table-dark text-center">
            <tr>
              <th style="width:50px;">No</th>
              <th>Nama Reason</th>
              <th style="width:180px;">Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php while($row = mysqli_fetch_assoc($reason)) { ?>
              <tr>
                <td></td> <!-- auto isi nomor oleh DataTables -->
                <td><?= $row['nama_reason']; ?></td>
                <td class="text-center">
                  <a href="edit_reason.php?reason_id=<?= $row['reason_id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                  <a href="hapus_reason.php?reason_id=<?= $row['reason_id']; ?>" 
                     onclick="return confirm('Yakin hapus reason ini?')" 
                     class="btn btn-danger btn-sm">Hapus</a>
                </td>
              </tr>
            <?php } ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- jQuery + DataTables -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

<script>
$(document).ready(function(){
    var t = $('#reasonTable').DataTable({
        columnDefs: [
            { targets: 0, orderable: false, searchable: false }, // kolom No tidak bisa sort/search
            { targets: 2, orderable: false } // kolom Aksi tidak bisa sort
        ],
        order: [[1, 'asc']] // urut default Nama Reason
    });

    // auto numbering kolom No
    t.on('order.dt search.dt', function(){
        let i = 1;
        t.cells(null, 0, {search:'applied', order:'applied'}).every(function(){
            this.data(i++);
        });
    }).draw();
});
</script>
</body>
</html>
