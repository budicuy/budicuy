<?php
include '../../koneksi.php';
include '../../sidebar.php';

// Ambil ID dari parameter
$reason_id = $_GET['reason_id'] ?? null;

// Jika tidak ada ID, kembali ke list
if (!$reason_id) {
    header("Location: reason_list.php");
    exit;
}

// Ambil data reason lama
$stmt = $conn->prepare("SELECT * FROM reason WHERE reason_id = ?");
$stmt->bind_param("i", $reason_id);
$stmt->execute();
$result = $stmt->get_result();
$data = $result->fetch_assoc();

if (!$data) {
    echo "<script>alert('Data reason tidak ditemukan'); window.location='reason_list.php';</script>";
    exit;
}

// Proses update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_reason = trim($_POST['nama_reason']);

    if ($nama_reason === "") {
        $error = "Nama reason wajib diisi!";
    } else {
        $update = $conn->prepare("UPDATE reason SET nama_reason = ? WHERE reason_id = ?");
        $update->bind_param("si", $nama_reason, $reason_id);

        if ($update->execute()) {
            echo "<script>alert('Reason berhasil diperbarui'); window.location='reason_list.php';</script>";
            exit;
        } else {
            $error = "Gagal update data: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Edit Reason</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>.main-content { margin-left: 220px; padding: 30px; }</style>
</head>
<body>
<div class="main-content">
  <h2 class="mb-4">Edit Reason Lembur</h2>

  <?php if (!empty($error)) { ?>
    <div class="alert alert-danger"><?= $error; ?></div>
  <?php } ?>

  <form method="post">
    <div class="mb-3">
      <label class="form-label">Nama Reason</label>
      <input type="text" name="nama_reason" value="<?= htmlspecialchars($data['nama_reason']); ?>" 
             class="form-control" required>
    </div>

    <button type="submit" class="btn btn-warning">Update</button>
    <a href="reason_list.php" class="btn btn-secondary">Batal</a>
  </form>
</div>
</body>
</html>
