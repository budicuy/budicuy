<?php
include '../../koneksi.php';

if (!isset($_GET['reason_id'])) {
    die("Error: Reason ID tidak ditemukan.");
}

$reason_id = intval($_GET['reason_id']);
$query = mysqli_query($conn, "DELETE FROM reason WHERE reason_id = $reason_id");

if ($query) {
    echo "<script>alert('Reason berhasil dihapus!'); window.location='reason_list.php';</script>";
} else {
    echo "<script>alert('Gagal menghapus reason!'); window.location='reason_list.php';</script>";
}
