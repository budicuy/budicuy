<?php
include '../../koneksi.php';
include '../../sidebar.php';

// Proses simpan data
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama_reason = mysqli_real_escape_string($conn, $_POST['nama_reason']);

    if (!empty($nama_reason)) {
        $query = "INSERT INTO reason (nama_reason) VALUES ('$nama_reason')";
        $result = mysqli_query($conn, $query);

        if ($result) {
            echo "<script>alert('Reason berhasil ditambahkan!'); window.location.href='reason_list.php';</script>";
        } else {
            echo "<script>alert('Gagal menambahkan reason: " . mysqli_error($conn) . "');</script>";
        }
    } else {
        echo "<script>alert('Reason tidak boleh kosong!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Tambah Reason</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .main-content { margin-left: 220px; padding: 30px; }
  </style>
</head>
<body>
<div class="main-content">
  <h2 class="mb-4">Tambah Alasan Lembur</h2>
  <div>
    <div>
      <form action="tambah_reason.php" method="POST">
        <div class="mb-3">
          <label for="nama_reason" class="form-label">Reason</label>
          <input type="text" class="form-control" id="nama_reason" name="nama_reason" required>
        </div>
        <button type="submit" class="btn btn-success">Simpan</button>
        <a href="reason_list.php" class="btn btn-secondary">Kembali</a>
      </form>
    </div>
  </div>
</div>
</body>
</html>
