<?php
include '../koneksi.php';
require '../vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\NumberFormat;

// Ambil bulan & tahun
$bulan = isset($_GET['bulan']) ? $_GET['bulan'] : date('n');
$tahun = isset($_GET['tahun']) ? $_GET['tahun'] : date('Y');

$spreadsheet = new Spreadsheet();

/**
 * ================
 * SHEET 1: ABSENSI
 * ================
 */
$sheet1 = $spreadsheet->getActiveSheet();
$sheet1->setTitle("Absensi");

$sqlAbsensi = "SELECT a.id_absen, a.nik, k.nama, a.tanggal, a.jam_masuk, a.jam_keluar, a.is_lembur
               FROM absensi a
               JOIN karyawan k ON a.nik = k.id_nik
               WHERE MONTH(a.tanggal) = ? AND YEAR(a.tanggal) = ?";
$stmt = $conn->prepare($sqlAbsensi);
$stmt->bind_param("ii", $bulan, $tahun);
$stmt->execute();
$resAbsensi = $stmt->get_result();

// Header
$headers1 = ['No','NIK','Nama','Tanggal','Jam Masuk','Jam Keluar','Lembur'];
$sheet1->fromArray($headers1, NULL, 'A1');

// Data
$rowNum = 2; $no=1;
while($row = $resAbsensi->fetch_assoc()){
    $sheet1->fromArray([
        $no++,
        $row['nik'],
        $row['nama'],
        $row['tanggal'],
        $row['jam_masuk'],
        $row['jam_keluar'],
        $row['is_lembur'] ? 'Ya' : 'Tidak'
    ], NULL, 'A'.$rowNum++);
}

/**
 * ======================
 * SHEET 2: OVERTIME DETAIL
 * ======================
 */
$sheet2 = $spreadsheet->createSheet();
$sheet2->setTitle("Overtime Detail");

$sqlDetail = "SELECT od.id_detail, od.id_nik, k.nama, od.tanggal, od.jam_in, od.jam_out, 
                     od.total_jam, od.biaya, r.nama_reason
              FROM overtime_detail od
              JOIN karyawan k ON od.id_nik = k.id_nik
              LEFT JOIN reason r ON od.reason_id = r.reason_id
              WHERE MONTH(od.tanggal) = ? AND YEAR(od.tanggal) = ?";
$stmt = $conn->prepare($sqlDetail);
$stmt->bind_param("ii", $bulan, $tahun);
$stmt->execute();
$resDetail = $stmt->get_result();

// Header
$headers2 = ['No','NIK','Nama','Tanggal','Jam In','Jam Out','Total Jam','Biaya','Alasan'];
$sheet2->fromArray($headers2, NULL, 'A1');

// Data
$rowNum = 2; $no=1;
while($row = $resDetail->fetch_assoc()){
    $sheet2->fromArray([
        $no++,
        $row['id_nik'],
        $row['nama'],
        $row['tanggal'],
        $row['jam_in'],
        $row['jam_out'],
        $row['total_jam'],
        $row['biaya'],
        $row['nama_reason'] ?? '-'
    ], NULL, 'A'.$rowNum++);
}
$lastRow2 = $rowNum - 1;
$sheet2->getStyle("H2:H$lastRow2")
       ->getNumberFormat()
       ->setFormatCode('"Rp" #,##0');

/**
 * =====================
 * SHEET 3: OVERTIME REKAP
 * =====================
 */

// Hitung jumlah hari kerja (Senin–Jumat) dalam bulan & tahun
function getHariKerja($bulan, $tahun) {
    $hariKerja = 0;
    $totalHari = cal_days_in_month(CAL_GREGORIAN, $bulan, $tahun);
    for ($i=1; $i <= $totalHari; $i++) {
        $day = date('N', strtotime("$tahun-$bulan-$i")); // 1=Senin ... 7=Minggu
        if ($day < 6) { // Senin-Jumat
            $hariKerja++;
        }
    }
    return $hariKerja;
}
$hariKerja = getHariKerja($bulan, $tahun);

$sheet3 = $spreadsheet->createSheet();
$sheet3->setTitle("Overtime Rekap");

$sqlRekap = "SELECT orp.id_rekap, orp.id_nik, k.nama, d.nama_departemen, v.nama_vendor,
                    orp.total_jam, orp.total_biaya, gp.gaji_pokok, orp.ranking
             FROM overtime_rekap orp
             JOIN karyawan k ON orp.id_nik = k.id_nik
             JOIN vendor v ON k.id_vendor = v.id_vendor
             JOIN departemen d ON k.id_dept = d.id_dept
             LEFT JOIN gaji_pokok gp ON gp.id_nik = k.id_nik
             WHERE orp.bulan = ? AND orp.tahun = ?
             ORDER BY orp.ranking ASC";
$stmt = $conn->prepare($sqlRekap);
$stmt->bind_param("ii", $bulan, $tahun);
$stmt->execute();
$resRekap = $stmt->get_result();

// Header
$headers3 = ['No','NIK','Nama','Departemen','Vendor','Total Jam','Total Biaya','Gaji Pokok','Ranking','Avg Ovt by Day'];
$sheet3->fromArray($headers3, NULL, 'A1');

// Data
$rowNum = 2; $no=1;
while($row = $resRekap->fetch_assoc()){
    $avgOvt = ($hariKerja > 0) ? $row['total_jam'] / $hariKerja : 0;

    $sheet3->fromArray([
        $no++,
        $row['id_nik'],
        $row['nama'],
        $row['nama_departemen'],
        $row['nama_vendor'],
        $row['total_jam'],
        $row['total_biaya'],
        $row['gaji_pokok'],
        $row['ranking'],
        $avgOvt
    ], NULL, 'A'.$rowNum++);
}
$lastRow3 = $rowNum - 1;
$sheet3->getStyle("G2:G$lastRow3")
       ->getNumberFormat()
       ->setFormatCode('"Rp" #,##0');
$sheet3->getStyle("H2:H$lastRow3")
       ->getNumberFormat()
       ->setFormatCode('"Rp" #,##0');

/**
 * =====================
 * FORMAT HEADER & AUTO WIDTH
 * =====================
 */
foreach ($spreadsheet->getAllSheets() as $sheet) {
    $highestCol = $sheet->getHighestColumn();
    $sheet->getStyle("A1:{$highestCol}1")->getFont()->setBold(true);
    foreach (range('A', $highestCol) as $col) {
        $sheet->getColumnDimension($col)->setAutoSize(true);
    }
}

/**
 * =====================
 * EXPORT FILE
 * =====================
 */
$filename = "Laporan_$bulan-$tahun.xlsx";
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header("Content-Disposition: attachment;filename=\"$filename\"");
header('Cache-Control: max-age=0');

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
