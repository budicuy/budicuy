<?php
include '../koneksi.php';
// pastikan hanya user login yang bisa akses

// Ambil bulan & tahun dari request (default bulan sekarang)
$bulan = isset($_GET['bulan']) ? $_GET['bulan'] : date('n');
$tahun = isset($_GET['tahun']) ? $_GET['tahun'] : date('Y');

// 1. Generate data ke overtime_detail dari absensi
$sqlDetail = "
INSERT INTO overtime_detail (id_nik, tanggal, jam_in, jam_out, total_jam, biaya, reason_id)
SELECT a.nik, a.tanggal, a.jam_masuk, a.jam_keluar, a.total_lembur,
       (
         CASE 
           WHEN a.total_lembur <= 0 THEN 0
           WHEN a.total_lembur = 1 THEN (gp.gaji_pokok / 173) * 1.5
           WHEN a.total_lembur > 1 THEN 
                (gp.gaji_pokok / 173) * (1.5 + (a.total_lembur - 1) * 2)
         END
       ) AS biaya_lembur,
       a.reason_id
FROM absensi a
JOIN gaji_pokok gp ON gp.id_nik = a.nik
WHERE a.is_lembur = 1
  AND MONTH(a.tanggal) = ? AND YEAR(a.tanggal) = ?
  AND NOT EXISTS (
      SELECT 1 FROM overtime_detail od 
      WHERE od.id_nik = a.nik AND od.tanggal = a.tanggal
  )";


$stmtDetail = $conn->prepare($sqlDetail);
$stmtDetail->bind_param("ii", $bulan, $tahun);
$stmtDetail->execute();

// 2. Hitung rekap lembur per karyawan
$sqlRekap = "
    INSERT INTO overtime_rekap (id_nik, bulan, tahun, total_jam, total_biaya, persentase, ranking)
    SELECT a.nik, ?, ?, 
           SUM(a.total_lembur) AS total_jam,
           SUM(
             CASE 
               WHEN a.total_lembur <= 0 THEN 0
               WHEN a.total_lembur = 1 THEN (gp.gaji_pokok / 173) * 1.5
               WHEN a.total_lembur > 1 THEN 
                    (gp.gaji_pokok / 173) * (1.5 + (a.total_lembur - 1) * 2)
             END
           ) AS total_biaya,
           NULL AS persentase,
           NULL AS ranking
    FROM absensi a
    JOIN gaji_pokok gp ON gp.id_nik = a.nik
    WHERE a.is_lembur = 1
      AND MONTH(a.tanggal) = ? AND YEAR(a.tanggal) = ?
    GROUP BY a.nik
    ON DUPLICATE KEY UPDATE 
        total_jam = VALUES(total_jam),
        total_biaya = VALUES(total_biaya)";

$stmtRekap = $conn->prepare($sqlRekap);
$stmtRekap->bind_param("iiii", $bulan, $tahun, $bulan, $tahun);
$stmtRekap->execute();

// 3. Update ranking berdasarkan total jam lembur
$conn->query("SET @rank := 0");
$sqlRanking = "UPDATE overtime_rekap r
               JOIN (
                   SELECT id_rekap, (@rank := @rank + 1) AS ranking
                   FROM overtime_rekap
                   WHERE bulan = $bulan AND tahun = $tahun
                   ORDER BY total_jam DESC
               ) ranked ON r.id_rekap = ranked.id_rekap
               SET r.ranking = ranked.ranking";
$conn->query($sqlRanking);

// 4. Hitung persentase kontribusi biaya lembur
$sqlTotal = "SELECT SUM(total_biaya) AS grand_total 
             FROM overtime_rekap 
             WHERE bulan = $bulan AND tahun = $tahun";
$resTotal = $conn->query($sqlTotal);
$grand = $resTotal->fetch_assoc()['grand_total'];

if ($grand > 0) {
    $sqlPersen = "UPDATE overtime_rekap 
                  SET persentase = (total_biaya / $grand) * 100
                  WHERE bulan = $bulan AND tahun = $tahun";
    $conn->query($sqlPersen);
}

// Redirect balik ke laporan detail
header("Location: ../laporan/laporan_detail.php?bulan=$bulan&tahun=$tahun&msg=generated");
exit;
