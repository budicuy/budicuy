<?php
include 'koneksi.php';

// ==========================
// Hitung total karyawan
// ==========================
$total_karyawan = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM karyawan"))['total'];

// ==========================
// Hitung absensi hari ini
// ==========================
$total_absensi = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM absensi WHERE tanggal = CURDATE()"))['total'];

// ==========================
// Ambil filter bulan & tahun
// ==========================
$filter_bulan = isset($_GET['bulan']) ? intval($_GET['bulan']) : date('m');
$filter_tahun = isset($_GET['tahun']) ? intval($_GET['tahun']) : date('Y');

// ==========================
// Absensi per bulan
// ==========================
$labels_bulan = [];
$absensi_per_bulan = [];
for ($m=1; $m<=12; $m++) {
    $row = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) AS total FROM absensi WHERE MONTH(tanggal)=$m AND YEAR(tanggal)=$filter_tahun"));
    $labels_bulan[] = "Bulan $m";
    $absensi_per_bulan[] = intval($row['total']);
}

// ==========================
// Absensi per hari
// ==========================
$days_in_month = cal_days_in_month(CAL_GREGORIAN, $filter_bulan, $filter_tahun);
$labels_hari = [];
$absensi_per_hari = [];
for ($d=1; $d<=$days_in_month; $d++) {
    $date = sprintf("%04d-%02d-%02d", $filter_tahun, $filter_bulan, $d);
    $row = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) AS total FROM absensi WHERE tanggal='$date'"));
    $labels_hari[] = $d;
    $absensi_per_hari[] = intval($row['total']);
}

// ==========================
// Doughnut chart: Absensi vs Sisa Karyawan
// ==========================
$total_absensi_tahun = array_sum($absensi_per_bulan);
$doughnut_labels = json_encode(['Absensi','Sisa Karyawan']);
$doughnut_data = json_encode([$total_absensi_tahun,max(0,$total_karyawan-$total_absensi_tahun)]);

// ==========================
// Mixed chart: Persentase per bulan
// ==========================
$persentase_bulan = array_map(fn($a)=> round($total_karyawan ? ($a/$total_karyawan*100) : 0,1), $absensi_per_bulan);

// ==========================
// Radar chart: Absensi per Departemen
// ==========================
$labels_dept = [];
$absensi_per_dept = [];
$res = mysqli_query($conn,"SELECT d.nama_departemen, COUNT(a.id_absen) AS total
    FROM karyawan k
    LEFT JOIN departemen d ON k.id_dept=d.id_dept
    LEFT JOIN absensi a ON a.nik=k.id_nik AND YEAR(a.tanggal)=$filter_tahun
    GROUP BY d.nama_departemen");
while($row = mysqli_fetch_assoc($res)){
    $labels_dept[] = $row['nama_departemen'];
    $absensi_per_dept[] = intval($row['total']);
}

// ==========================
// Encode JSON untuk Chart.js
// ==========================
$labels_bulan_json = json_encode($labels_bulan);
$absensi_bulan_json = json_encode($absensi_per_bulan);
$labels_hari_json = json_encode($labels_hari);
$absensi_hari_json = json_encode($absensi_per_hari);
$persentase_bulan_json = json_encode($persentase_bulan);
$labels_dept_json = json_encode($labels_dept);
$absensi_dept_json = json_encode($absensi_per_dept);
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Dashboard - Sistem Absensi</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
body {margin:0;padding:0;background-color:#f8f9fa;}
.main-content {margin-left:220px;padding:30px;}
.card {border:none;border-radius:15px;box-shadow:0 4px 6px rgba(0,0,0,0.1);}
.header {background-color:#fff;padding:20px;border-bottom:1px solid #dee2e6;margin-bottom:30px;}
.filter-form {margin-bottom:20px;}
.chart-canvas {max-height:300px;width:100%;}
</style>
</head>
<body>

<?php include __DIR__.'/sidebar.php'; ?>

<div class="main-content">
  <!-- Header -->
  <div class="header">
    <h2 class="mb-0">Selamat Datang di Sistem Absensi</h2>
  </div>

  <!-- Info Cards -->
  <div class="row g-4 mb-4">
    <div class="col-md-6">
      <div class="card bg-primary text-white">
        <div class="card-body d-flex align-items-center">
          <i class="bi bi-people-fill display-4 me-3"></i>
          <div>
            <h5>Total Karyawan</h5>
            <p class="fs-3"><?= $total_karyawan ?> Orang</p>
          </div>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="card bg-success text-white">
        <div class="card-body d-flex align-items-center">
          <i class="bi bi-calendar-check-fill display-4 me-3"></i>
          <div>
            <h5>Absensi Hari Ini</h5>
            <p class="fs-3"><?= $total_absensi ?> Data</p>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Filter Bulan & Tahun -->
  <form method="get" class="filter-form row g-2">
    <div class="col-md-3">
      <select name="bulan" class="form-select">
        <?php for($m=1;$m<=12;$m++): $selected=($m==$filter_bulan)?'selected':''; ?>
        <option value="<?= $m ?>" <?= $selected ?>>Bulan <?= $m ?></option>
        <?php endfor; ?>
      </select>
    </div>
    <div class="col-md-3">
      <select name="tahun" class="form-select">
        <?php $current_year=date('Y'); for($y=$current_year-5;$y<=$current_year;$y++):
            $selected=($y==$filter_tahun)?'selected':''; ?>
        <option value="<?= $y ?>" <?= $selected ?>><?= $y ?></option>
        <?php endfor; ?>
      </select>
    </div>
    <div class="col-md-2">
      <button type="submit" class="btn btn-primary w-100">Filter</button>
    </div>
  </form>

  <!-- Charts -->
  <div class="row g-4">
    <div class="col-md-6">
      <div class="card mb-4">
        <div class="card-body">
          <h5>Absensi Bulanan (<?= $filter_tahun ?>)</h5>
          <canvas id="absensiChart" class="chart-canvas"></canvas>
        </div>
      </div>
    </div>

    <div class="col-md-6">
      <div class="card mb-4">
        <div class="card-body">
          <h5>Absensi Harian (<?= $filter_bulan ?>/<?= $filter_tahun ?>)</h5>
          <canvas id="lineChart" class="chart-canvas"></canvas>
        </div>
      </div>
    </div>

    <div class="col-md-6">
      <div class="card mb-4">
        <div class="card-body">
          <h5>Doughnut: Absensi vs Sisa Karyawan</h5>
          <canvas id="doughnutChart" class="chart-canvas"></canvas>
        </div>
      </div>
    </div>

    <div class="col-md-6">
      <div class="card mb-4">
        <div class="card-body">
          <h5>Mixed Chart: Absensi & Persentase</h5>
          <canvas id="mixedChart" class="chart-canvas"></canvas>
        </div>
      </div>
    </div>

    <div class="col-md-6">
      <div class="card mb-4">
        <div class="card-body">
          <h5>Radar Chart: Absensi per Departemen</h5>
          <canvas id="radarChart" class="chart-canvas"></canvas>
        </div>
      </div>
    </div>

    <div class="col-md-6">
      <div class="card mb-4">
        <div class="card-body">
          <h5>Polar Area: Absensi Bulanan</h5>
          <canvas id="polarChart" class="chart-canvas"></canvas>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
// Bar Chart
new Chart(document.getElementById('absensiChart').getContext('2d'), {
    type:'bar',
    data:{labels:<?= $labels_bulan_json ?>, datasets:[{label:'Jumlah Absensi', data:<?= $absensi_bulan_json ?>, backgroundColor:'rgba(54,162,235,0.7)'}]},
    options:{responsive:true, maintainAspectRatio:false, plugins:{legend:{display:false}, title:{display:true,text:'Absensi Bulanan'}}, scales:{y:{beginAtZero:true}}}
});

// Line Chart
new Chart(document.getElementById('lineChart').getContext('2d'), {
    type:'line',
    data:{labels:<?= $labels_hari_json ?>, datasets:[{label:'Jumlah Absensi', data:<?= $absensi_hari_json ?>, borderColor:'rgba(255,99,132,0.8)', backgroundColor:'rgba(255,99,132,0.2)', fill:true, tension:0.3}]},
    options:{responsive:true, maintainAspectRatio:false, plugins:{legend:{display:false}, title:{display:true,text:'Absensi Harian'}}, scales:{y:{beginAtZero:true}}}
});

// Doughnut Chart
new Chart(document.getElementById('doughnutChart').getContext('2d'), {
    type:'doughnut',
    data:{labels:<?= $doughnut_labels ?>, datasets:[{data:<?= $doughnut_data ?>, backgroundColor:['rgba(54,162,235,0.7)','rgba(201,203,207,0.7)'], hoverOffset:10}]},
    options:{responsive:true, maintainAspectRatio:false, plugins:{legend:{position:'top'}, title:{display:true,text:'Absensi vs Sisa Karyawan'}}}
});

// Mixed Chart
new Chart(document.getElementById('mixedChart').getContext('2d'), {
    data:{
        labels: <?= $labels_bulan_json ?>,
        datasets:[
            {type:'bar', label:'Jumlah Absensi', data:<?= $absensi_bulan_json ?>, backgroundColor:'rgba(54,162,235,0.7)'},
            {type:'line', label:'Persentase (%)', data:<?= $persentase_bulan_json ?>, borderColor:'rgba(255,99,132,0.8)', borderWidth:2, fill:false, yAxisID:'y1', tension:0.3}
        ]
    },
    options:{
        responsive:true,
        maintainAspectRatio:false,
        plugins:{legend:{position:'top'}, title:{display:true,text:'Absensi & Persentase per Bulan'}},
        scales:{
            y:{beginAtZero:true, title:{display:true,text:'Jumlah Absensi'}},
            y1:{beginAtZero:true, position:'right', title:{display:true,text:'Persentase (%)'}, grid:{drawOnChartArea:false}}
        }
    }
});

// Radar Chart
new Chart(document.getElementById('radarChart').getContext('2d'),{
    type:'radar',
    data:{labels: <?= $labels_dept_json ?>, datasets:[{label:'Jumlah Absensi', data: <?= $absensi_dept_json ?>, backgroundColor:'rgba(54,162,235,0.2)', borderColor:'rgba(54,162,235,1)', pointBackgroundColor:'rgba(54,162,235,1)'}]},
    options:{responsive:true, maintainAspectRatio:false, plugins:{title:{display:true,text:'Absensi per Departemen'}}}
});

// Polar Area
new Chart(document.getElementById('polarChart').getContext('2d'),{
    type:'polarArea',
    data:{labels: <?= $labels_bulan_json ?>, datasets:[{label:'Jumlah Absensi', data: <?= $absensi_bulan_json ?>, backgroundColor:[
        'rgba(255,99,132,0.7)','rgba(54,162,235,0.7)','rgba(255,206,86,0.7)',
        'rgba(75,192,192,0.7)','rgba(153,102,255,0.7)','rgba(255,159,64,0.7)',
        'rgba(199,199,199,0.7)','rgba(83,102,255,0.7)','rgba(255,102,178,0.7)',
        'rgba(102,255,102,0.7)','rgba(255,204,102,0.7)','rgba(102,255,255,0.7)'
    ]}]} ,
    options:{responsive:true, maintainAspectRatio:false, plugins:{title:{display:true,text:'Polar Area Absensi Bulanan'}}}
});
</script>

</body>
</html>
